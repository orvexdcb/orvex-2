const test=require('node:test'),assert=require('node:assert/strict');
const {acct,mkSale,mkLedger,shop}=require('./helpers');
const A=acct();
const r2=n=>Math.round(n*100)/100;
function mk(opt){
  const db=shop();db.warehouses=[{id:'w2',name:'فرع 2',active:true}];db.transfers=[];db.settings={tax:0,...(opt&&opt.settings)};
  db.products=[{id:'a',name:'أ',stock:50,cost:4,price:6,wh:{}},{id:'b',name:'ب',stock:10,cost:40,price:70,wh:{}}];
  db.customers=[{id:'c1',name:'عميل',balance:0,creditLimit:(opt&&opt.limit)||0}];
  const c=mkSale(db,opt);return{db,c}}
function sell(c,lines,co,paid){c.state.cart=lines;c.state.co=Object.assign({cid:'',disc:0,method:'cash',paid:null},co);c.finalize(c.state.co.method,paid==null?9e9:paid)}
const bal=(ls)=>{const d=r2(ls.reduce((s,x)=>s+x.debit,0)),k=r2(ls.reduce((s,x)=>s+x.credit,0));return{d,k}};

/* ===== خصم المخزون عند إتمام البيع (finalize الحقيقي من pos.js) ===== */
test('بيع نقدي: يخصم الكمية، يسجل الإيراد والضريبة والتكلفة، والقيد متوازن',()=>{
  const {db,c}=mk({settings:{tax:15}});
  sell(c,[{pid:'a',qty:10,price:6,dp:0},{pid:'b',qty:2,price:70,dp:10}]);
  assert.equal(db.sales.length,1);const s=db.sales[0];
  assert.equal(db.products[0].stock,40);assert.equal(db.products[1].stock,8);
  assert.equal(s.cost,r2(10*4+2*40));          /* التكلفة وقت البيع */
  assert.equal(s.net,r2(60+126));assert.equal(s.tax,r2(186*0.15));assert.equal(s.total,r2(186+27.9));assert.equal(s.paid,s.total);
  const l=A.saleLines(s),t=bal(l);assert.equal(t.d,t.k);
  const by=k=>l.filter(x=>x.key===k).reduce((a,x)=>a+x.debit-x.credit,0);
  assert.equal(r2(by('sales')),-186);assert.equal(r2(by('vat_out')),-27.9);assert.equal(by('cogs'),120);assert.equal(by('inventory'),-120)});
test('بيع آجل: الباقي يُضاف لرصيد العميل ويُثبَّت ذمة مدينة؛ بلا عميل أو بلا صلاحية يُرفض دون أي أثر',()=>{
  let {db,c}=mk();
  sell(c,[{pid:'a',qty:5,price:6,dp:0}],{cid:'c1',method:'credit'},0);
  assert.equal(db.customers[0].balance,30);assert.equal(db.products[0].stock,45);
  const l=A.saleLines(db.sales[0]);assert.equal(l.find(x=>x.key==='ar').debit,30);const t=bal(l);assert.equal(t.d,t.k);
  ({db,c}=mk());sell(c,[{pid:'a',qty:5,price:6,dp:0}],{cid:'',method:'credit'},0);
  assert.equal(db.sales.length,0);assert.equal(db.products[0].stock,50);
  ({db,c}=mk({can:false}));sell(c,[{pid:'a',qty:5,price:6,dp:0}],{cid:'c1',method:'credit'},0);
  assert.equal(db.sales.length,0);assert.equal(db.products[0].stock,50);assert.equal(db.customers[0].balance,0)});
test('حد الائتمان: الكاشير يُمنع دون أي أثر على المخزون أو الرصيد',()=>{
  const {db,c}=mk({limit:20,admin:false});
  sell(c,[{pid:'a',qty:5,price:6,dp:0}],{cid:'c1',method:'credit'},0);
  assert.equal(db.sales.length,0);assert.equal(db.products[0].stock,50);assert.equal(db.customers[0].balance,0)});
test('بيع من مخزن غير رئيسي: الإجمالي ينقص مرة واحدة وكمية المخزن الفرعي فقط، والرئيسي لا يتغير',()=>{
  const {db,c}=mk();const p=db.products[0];p.wh={w2:12};/* الرئيسي المشتق = 38 */
  c.ORVEX_INV3.setSaleWh('w2');
  sell(c,[{pid:'a',qty:5,price:6,dp:0}]);
  assert.equal(p.stock,45);assert.equal(p.wh.w2,7);assert.equal(c.ORVEX_INV3.whQty(p,'main'),38);
  assert.equal(db.sales[0].wh,'w2');assert.equal(db.sales[0].items[0].whq,5)});
test('منتج بتشغيلات: FEFO يسحب الأقرب انتهاءً ويُسجَّل على سطر الفاتورة',()=>{
  const {db,c}=mk();const p=db.products[0];p.trackBatch=true;p.stock=10;
  p.batches=[{no:'B2',qty:6,exp:'2027-05-01'},{no:'B1',qty:4,exp:'2026-12-01'}];
  sell(c,[{pid:'a',qty:7,price:6,dp:0}]);
  assert.equal(p.stock,3);assert.equal(JSON.stringify(db.sales[0].items[0].bt.map(x=>[x.no,x.q])),JSON.stringify([['B1',4],['B2',3]]));
  assert.equal(p.batches.find(b=>b.no==='B2').qty,3)});
test('بيع بدفعة منتهية الصلاحية يُنبَّه عليه',()=>{
  const {db,c}=mk();const p=db.products[0];p.trackBatch=true;p.stock=5;p.batches=[{no:'OLD',qty:5,exp:'2026-10-01'}];
  sell(c,[{pid:'a',qty:2,price:6,dp:0}]);assert.ok(c.__msgs.some(m=>/منتهية/.test(m)))});
test('منتج برقم تسلسلي: لا يتم البيع دون اختيار الأرقام، ثم تُعلَّم المباعة',()=>{
  const {db,c}=mk();const p=db.products[1];p.trackSerial=true;p.stock=3;p.serials=[{sn:'X1'},{sn:'X2'},{sn:'X3'}];
  sell(c,[{pid:'b',qty:2,price:70,dp:0}]);
  assert.equal(db.sales.length,0);assert.equal(p.stock,3);               /* توقف عند نافذة الاختيار */
  c.__serialPick={b:['X1','X3']};sell(c,[{pid:'b',qty:2,price:70,dp:0}]);
  assert.equal(db.sales.length,1);assert.equal(p.stock,1);
  assert.equal(JSON.stringify(p.serials.filter(x=>x.st==='sold').map(x=>x.sn)),'["X1","X3"]');assert.equal(JSON.stringify(db.sales[0].items[0].sn),'["X1","X3"]')});

/* ===== ربط البيع بالدفاتر ===== */
test('كل البيوعات تُنتج قيودًا متوازنة بمعرّفات حتمية لا تتغير عند إعادة الاشتقاق (لا تكرار بعد المزامنة)',()=>{
  const {db,c}=mk({settings:{tax:15}});
  sell(c,[{pid:'a',qty:3,price:6,dp:0}]);sell(c,[{pid:'b',qty:1,price:70,dp:5}],{cid:'c1',method:'credit'},10);
  const e1=A.expected(db,'2026-01-01'),e2=A.expected(db,'2026-01-01');
  assert.equal(e1.entries.length,2);assert.equal(e1.skipped.length,0);
  assert.deepEqual(e1.entries.map(e=>e.key+e.hash),e2.entries.map(e=>e.key+e.hash));
  e1.entries.forEach(e=>{const t=bal(e.lines);assert.equal(t.d,t.k)});
  const p=A.plan(db,{posted:{}},'2026-01-01','2026-11-10');assert.equal(p.actions.filter(a=>a.type==='post').length,2);
  const st={posted:{}};p.actions.forEach(a=>{st.posted[a.key]={v:a.v,hash:a.hash,active:true}});
  assert.equal(A.plan(db,st,'2026-01-01','2026-11-10').actions.length,0)});
test('ميزان المراجعة بعد بيعين: المخزون في الدفاتر = التكلفة المتبقية، والمتوازن دائمًا',()=>{
  const {db,c}=mk();db.purchases.push({id:'p1',no:'P1',date:'2026-11-01',total:200+400,paid:600,method:'cash'});
  sell(c,[{pid:'a',qty:10,price:6,dp:0}]);sell(c,[{pid:'b',qty:2,price:70,dp:0}]);
  const tb=mkLedger(db).tb('','');const rows=tb.rows||tb;
  const d=r2(rows.reduce((s,r)=>s+(r.debit||0),0)),k=r2(rows.reduce((s,r)=>s+(r.credit||0),0));assert.equal(d,k);
  const inv=rows.find(r=>/inventory|مخزون/.test(r.key||r.name||r.code||''));
  if(inv)assert.equal(r2((inv.debit||0)-(inv.credit||0)),r2(600-(10*4+2*40)))});
