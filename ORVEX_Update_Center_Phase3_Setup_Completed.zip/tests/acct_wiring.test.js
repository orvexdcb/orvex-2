const test=require('node:test'),assert=require('node:assert/strict'),fs=require('fs'),path=require('path');
const rd=f=>fs.readFileSync(path.join(__dirname,'..',f),'utf8');
const sql=rd('supabase/proposed/20261110120000_acct_core.sql'),ui=rd('accounting-ui.js'),srv=rd('server.js'),acc=rd('accounting.js');
test('كل دالة rpc تستدعيها الواجهة موجودة في المسودة',()=>{
  const used=new Set();[ui,acc].forEach(s=>{for(const m of s.matchAll(/rpc\('([a-z_]+)'/g))used.add(m[1])});
  assert.ok(used.size>=5,[...used].join());
  for(const f of used)assert.match(sql,new RegExp('create function public\\.'+f+'\\('),'ناقصة: '+f);
});
test('المسودة تستعمل أسماء الدوال private.* كما في migrations الموجودة',()=>{
  assert.doesNotMatch(sql,/public\.my_(role|shop|device_ok)\(/);
  const mig=fs.readdirSync(path.join(__dirname,'..','supabase/migrations')).map(f=>rd('supabase/migrations/'+f)).join('\n');
  for(const f of ['my_role','my_shop','my_device_ok','my_shop_licensed'])assert.match(mig,new RegExp('private\\.'+f+'\\('),f);
});
test('الجسر والواجهة يقرآن acct_* ولا يكتبان مباشرة على الجداول',()=>{
  assert.match(srv,/rest\/v1\/acct_accounts\?/);assert.doesNotMatch(srv,/rest\/v1\/accounts\?/);
  assert.doesNotMatch(ui,/b\.(post|patch)\(/);assert.match(ui,/acct_periods\?/);
});
test('المسودة ترفض القيد بأقل من سطرين',()=>{assert.match(sql,/jsonb_array_length\(p_entry->'lines'\) < 2/)});
