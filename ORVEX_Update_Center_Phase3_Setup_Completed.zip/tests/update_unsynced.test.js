const test=require('node:test'),assert=require('node:assert/strict'),vm=require('vm');
const {read}=require('./helpers');
/* يشغّل pwa.js الحقيقي مع متصفح مبسّط، ويضغط زر «تحديث البرنامج» الحقيقي */
function mkPwa(status,opt){
  opt=opt||{};const log=[],els=[],ivs=[],handlers={};
  const mkEl=()=>{const e={style:{},children:[],_h:{},setAttribute(){},addEventListener(t,f){e._h[t]=f},appendChild(c){e.children.push(c)},remove(){const i=els.indexOf(e);if(i>=0)els.splice(i,1)}};return e};
  const store={set:(k,v)=>log.push('ls.set:'+k),removeItem:k=>log.push('ls.remove:'+k),clear:()=>log.push('ls.clear'),getItem:()=>null};
  const ctx={console,setInterval(f){ivs.push(f);return 0},clearInterval(){},setTimeout:(f,ms)=>{if(!ms||ms<1000)return setTimeout(f,ms);return 0},
    navigator:{onLine:opt.online!==false},location:{protocol:'file:',reload:()=>log.push('reload')},
    localStorage:store,sessionStorage:store,caches:{delete:k=>{log.push('caches.delete:'+k);return Promise.resolve()}},
    document:{createElement:mkEl,getElementById:id=>els.find(e=>e.id===id)||null,querySelector:()=>null,body:{appendChild:e=>els.push(e)}},
    confirm:()=>{log.push('confirm');return opt.confirm!==false},alert:m=>log.push('alert'),toast:m=>log.push('toast:'+m),
    __orvexStatus:()=>status,__orvexPrepareUpdate:()=>log.push('prepare'),logout:()=>log.push('logout'),orvexLogout:()=>log.push('logout')};
  ctx.window=ctx;ctx.addEventListener=(t,f)=>{(handlers[t]=handlers[t]||[]).push(f)};ctx.globalThis=ctx;
  vm.createContext(ctx);vm.runInContext(read('pwa.js'),ctx,{filename:'pwa.js'});
  (handlers.load||[]).forEach(f=>f());
  const btn=()=>els.find(e=>e.id==='orvexManualUpdate');
  const click=async()=>{const b=btn();assert.ok(b,'زر التحديث غير ظاهر');await b._h.click();await new Promise(r=>setTimeout(r,5))};
  return{log,click,btn,ctx,status,tick:()=>ivs.forEach(f=>f())};
}
const FORBID=/^(ls\.(set|remove|clear)|caches\.delete|logout)/;

test('4أ) بيانات غير متزامنة (dirty): الزر لا يعيد التحميل ولا يمس أي تخزين أو جلسة',async()=>{
  const p=mkPwa({logged:true,dirty:true,busy:false});await p.click();
  assert.ok(!p.log.includes('reload'));assert.ok(!p.log.includes('prepare'));assert.ok(!p.log.some(x=>FORBID.test(x)),p.log.join(','));
  assert.ok(p.log.some(x=>x.startsWith('toast:')))});
test('4ب) مزامنة جارية (busy): نفس الحماية',async()=>{
  const p=mkPwa({logged:true,dirty:false,busy:true});await p.click();assert.ok(!p.log.includes('reload'));assert.ok(!p.log.includes('prepare'))});
test('4ج) بلا بيانات معلّقة: يحفظ الجلسة ثم يعيد التحميل مرة واحدة، دون مسح أي بيانات أو الخروج',async()=>{
  const p=mkPwa({logged:true,dirty:false,busy:false});await p.click();
  assert.equal(p.log.filter(x=>x==='reload').length,1);assert.ok(p.log.indexOf('prepare')>=0&&p.log.indexOf('prepare')<p.log.indexOf('reload'));
  assert.ok(!p.log.some(x=>FORBID.test(x)),p.log.join(','));assert.equal(p.ctx.__orvexUpdating,true)});
test('رفض تأكيد المستخدم: لا شيء يحدث',async()=>{
  const p=mkPwa({logged:true,dirty:false,busy:false},{confirm:false});await p.click();assert.deepEqual(p.log.filter(x=>x!=='confirm'),[])});
test('تحديثات متتالية: كل ضغطة تحفظ الجلسة قبل التحميل ولا تفقد شيئًا',async()=>{
  const p=mkPwa({logged:true,dirty:false,busy:false});
  for(let i=0;i<3;i++){const b=p.btn();b.disabled=false;await b._h.click();await new Promise(r=>setTimeout(r,5))}
  assert.equal(p.log.filter(x=>x==='prepare').length,3);assert.equal(p.log.filter(x=>x==='reload').length,3);assert.ok(!p.log.some(x=>FORBID.test(x)))});
test('الزر لا يظهر قبل تسجيل الدخول ويظهر بعده ويختفي عند الخروج',()=>{
  const st={logged:false},p=mkPwa(st);assert.equal(p.btn(),undefined);
  st.logged=true;p.tick();assert.ok(p.btn());st.logged=false;p.tick();assert.equal(p.btn(),undefined)});

/* عقد المصدر: ما يضمن بقاء البيانات غير المتزامنة وعدم تكرارها بعد إعادة التحميل */
const S=read('server.js');
test('المزامنة: العملية تُحفظ في inflight قبل الإرسال (معرّف ثابت يمنع تكرار الخصم عند إعادة المحاولة)',()=>{
  const a=S.indexOf('inflightAdd(t,dl,op,rows)'),b=S.indexOf('inflightDone(op);applyOp');assert.ok(a>0&&b>a)});
test('بعد إعادة التحميل: وجود inflight يعيد dirty ويُدفَع، والرفع upsert بمفتاح id (لا صفوف مكررة)',()=>{
  assert.match(S,/if\(ifGet\(\)\.length\)\{SB\.dirty=true/);assert.match(S,/resolution=merge-duplicates/);assert.match(S,/on_conflict=\$\{m\?'id':'shop_id,kind,id'\}/)});
test('استرجاع التعديلات المحلية (recoverLocal) يُستدعى عند الدخول/الاستعادة ويحفظ نسخة prelogin قبل أي دمج',()=>{
  assert.match(S,/putBackup\('prelogin'/);assert.ok(S.indexOf("putBackup('prelogin'")<S.indexOf('recoverLocal(old,SB.shop)'))});
test('pwa.js لا يحوي أي مسح تخزين أو خروج، وsw.js لا يحذف إلا كاشات الإصدارات القديمة',()=>{
  const P=read('pwa.js');assert.ok(!/removeItem|localStorage\.clear|sessionStorage\.clear|indexedDB|caches\.delete|signOut|logout\(/.test(P));
  const W=read('sw.js');assert.match(W,/filter\(x=>x!==VER&&/);assert.match(W,/x\.startsWith\('orvex-root-'\)/);assert.ok(!/localStorage|indexedDB|IDBDatabase/.test(W))});
