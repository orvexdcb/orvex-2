const test=require('node:test'),assert=require('node:assert/strict');
const C=require('../costing.js');
const IN=(d,q,u,x={})=>({type:'in',date:d,qty:q,unitCost:u,ref:'in'+d+q,...x}),OUT=(d,q,x={})=>({type:'out',date:d,qty:q,ref:'out'+d+q,...x});
test('FIFO: بيع 15 من (10@5 ثم 10@7) = 85 والمتبقي 5@7=35',()=>{
  const r=C.value([IN('2026-11-01',10,5),IN('2026-11-02',10,7),OUT('2026-11-03',15)],'fifo');
  assert.equal(r.cogs,85);assert.equal(r.remQty,5);assert.equal(r.remValue,35);assert.equal(r.outs[0].unit,5.6667)});
test('WAC: نفس الحركات: متوسط 6 → تكلفة 90 والمتبقي 5@6=30',()=>{
  const r=C.value([IN('2026-11-01',10,5),IN('2026-11-02',10,7),OUT('2026-11-03',15)],'wac');
  assert.equal(r.cogs,90);assert.equal(r.remValue,30)});
test('WAC متحرك: بيع بين شراءين يستخدم المتوسط عند لحظة البيع',()=>{
  const r=C.value([IN('2026-11-01',10,5),OUT('2026-11-02',4),IN('2026-11-03',10,9),OUT('2026-11-04',6)],'wac');
  assert.equal(r.outs[0].cost,20);/* 4×5 */ assert.equal(r.outs[1].cost,r2(6*((6*5+10*9)/16)));assert.equal(r.remQty,10)});
const r2=n=>Math.round(n*100)/100;
test('التكلفة المحددة: الصرف من التشغيلة المحددة فقط',()=>{
  const r=C.value([IN('2026-11-01',5,10,{lot:'A'}),IN('2026-11-02',5,20,{lot:'B'}),OUT('2026-11-03',3,{lot:'B'}),OUT('2026-11-04',2,{lot:'A'})],'specific');
  assert.equal(r.outs[0].cost,60);assert.equal(r.outs[1].cost,20);assert.equal(r.remQty,5);assert.equal(r.remValue,r2(3*10+2*20))});
test('مرتجع بيع يعيد الكمية بتكلفتها الأصلية كطبقة جديدة (لا ربح وهمي)',()=>{
  const r=C.value([IN('2026-11-01',10,5),OUT('2026-11-02',10),{type:'ret_in',date:'2026-11-03',qty:2,unitCost:5,ref:'r'},OUT('2026-11-04',2)],'fifo');
  assert.equal(r.outs[0].cost,50);assert.equal(r.outs[1].cost,10);assert.equal(r.remQty,0);assert.equal(r.remValue,0)});
test('عجز المخزون: لا كميات سالبة، يُقيَّم على آخر تكلفة ويُعلَّم',()=>{
  const r=C.value([IN('2026-11-01',3,4),OUT('2026-11-02',5)],'fifo');
  assert.equal(r.shortQty,2);assert.equal(r.outs[0].short,true);assert.equal(r.outs[0].cost,20);assert.equal(r.remQty,0)});
test('رصيد افتتاحي يُستهلك أولًا في FIFO',()=>{
  const r=C.value([IN('2026-11-01',5,8),OUT('2026-11-02',6)],'fifo',{qty:4,cost:3});
  assert.equal(r.outs[0].cost,r2(4*3+2*8));assert.equal(r.remQty,3)});
test('الحتمية: ترتيب الإدخال لا يغيّر النتيجة (نفس النتيجة على كل جهاز)',()=>{
  const ev=[IN('2026-11-01',10,5),IN('2026-11-02',10,7),OUT('2026-11-03',15),OUT('2026-11-04',2)];
  const a=C.value(ev,'fifo'),b=C.value(ev.slice().reverse(),'fifo');assert.equal(JSON.stringify(a),JSON.stringify(b))});
test('التوفيق: قيمة المخزون المتبقي = المشتريات − تكلفة المباعة (لكل السياسات)',()=>{
  const ev=[IN('2026-11-01',10,5.33),IN('2026-11-02',7,6.1),OUT('2026-11-03',9),IN('2026-11-04',3,4),OUT('2026-11-05',5)];
  const bought=10*5.33+7*6.1+3*4;
  for(const m of['fifo','wac']){const r=C.value(ev,m);assert.ok(Math.abs(r.remValue+r.cogs-bought)<0.03,m+' '+(r.remValue+r.cogs)+' vs '+bought)}});
test('كميات صفرية/سالبة تُتجاهل',()=>{const r=C.value([IN('2026-11-01',0,5),IN('2026-11-01',-3,5),OUT('2026-11-02',0)],'fifo');assert.equal(r.remQty,0);assert.equal(r.outs.length,0)});
test('movements/valueProduct من مستندات المحل: تكاليف الوصول تدخل في تكلفة الوحدة، والملغاة تُهمَل، والافتتاحي من المخزون الحالي',()=>{
  const db={purchases:[{id:'p1',date:'2026-11-01',lines:[{pid:'x',qty:10,net:100,lc:20}]},{id:'p2',date:'2026-11-02',void:true,lines:[{pid:'x',qty:99,net:999}]}],
    sales:[{id:'s1',date:'2026-11-03',items:[{pid:'x',qty:4}]},{id:'s2',date:'2026-11-03',void:true,items:[{pid:'x',qty:50}]}],returns:[]};
  const p={id:'x',stock:8,cost:1};/* 8 = 2 افتتاحي + 10 − 4 */
  const r=C.valueProduct(db,p,'fifo');
  assert.equal(r.outs.length,1);assert.equal(r.outs[0].cost,r2(2*1+2*12));assert.equal(r.remQty,8);
  assert.equal(r.remValue,r2(8*12))});
test('العزل: منتج لا يتأثر بحركات منتج آخر',()=>{
  const db={purchases:[{id:'p1',date:'2026-11-01',lines:[{pid:'a',qty:5,net:50},{pid:'b',qty:5,net:500}]}],sales:[],returns:[]};
  assert.equal(C.valueProduct(db,{id:'a',stock:5,cost:10},'fifo').remValue,50)});
