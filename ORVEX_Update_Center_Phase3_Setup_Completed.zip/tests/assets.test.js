const test=require('node:test'),assert=require('node:assert/strict'),vm=require('vm');
const {read,acct,shop}=require('./helpers');
/* يحمّل ledger.js وassets3.js الحقيقيين في سياق واحد (كما في index.html) مع db وهمي */
function mk(opt){
  opt=opt||{};let n=0;const db=shop();db.assets=[];
  const ctx={db,console,uid:()=>'x'+(++n),today:()=>opt.today||'2026-11-10',can:()=>true,isAdmin:()=>opt.admin!==false,
    curUser:()=>({name:'tester'}),orvexLog(){},num:v=>{const x=parseFloat(v);return isFinite(x)?x:0},r2:v=>Math.round((parseFloat(v)||0)*100)/100,
    esc:s=>s,jsq:s=>s,money:v=>v,fdate:s=>s,toast(){},modal(){},chips(){return''},askConfirm(){},save(){},
    ORVEX_FIN:{lockDate:()=>opt.lock||''}};
  ctx.window=ctx;ctx.globalThis=ctx;vm.createContext(ctx);ctx.orvexAcct=acct();
  vm.runInContext(read('assets3.js'),ctx,{filename:'assets3.js'});
  vm.runInContext(read('ledger.js'),ctx,{filename:'ledger.js'});
  return {db,L:ctx.ORVEX_LED,A:ctx.ORVEX_ASSETS,ctx};
}
const base={name:'سيارة',cost:12000,date:'2026-01-15',lifeYears:1,salvage:0,fund:'cash'};
const bal=(L,code)=>{const r=L.tb().find(x=>x.code===code);return r?r.balance:0};
const add=(e,v)=>{const r=e.A.save('',Object.assign({},base,v));assert.ok(!r.err,r.err);return r.ok};

test('قسط ثابت: 11 شهرًا حتى نوفمبر، والمجموع = المجمّع',()=>{
  const e=mk(),a=add(e);const s=e.A.schedule(a);
  assert.equal(s.length,11);assert.equal(s.reduce((t,x)=>t+x.amt,0),11000);assert.equal(e.A.calc(a).acc,11000);assert.equal(e.A.calc(a).book,1000)});
test('الإهلاك لا يتجاوز (التكلفة − الخردة) ويتوقف بنهاية العمر، والتقريب لا يترك فرقًا',()=>{
  const e=mk({today:'2035-01-01'}),a=add(e,{cost:1000,salvage:100,lifeYears:3,date:'2026-01-01'});
  const s=e.A.schedule(a);assert.equal(s.length,36);assert.equal(Math.round(s.reduce((t,x)=>t+x.amt,0)*100)/100,900);
  assert.equal(e.A.calc(a).book,100)});
test('أصل بلا ربط (fund=none): لا قيود ولا أثر على الميزان',()=>{
  const e=mk();add(e,{fund:'none'});assert.equal(e.A.entries({},'x').length,0);assert.equal(e.L.tb().length,0)});
test('أصل مربوط نقدًا: شراء + إهلاك، الميزان والميزانية متوازنان والأرصدة صحيحة',()=>{
  const e=mk();add(e);const tb=e.L.tb(),t=e.L.totals(tb);
  assert.equal(t.debit,t.credit);assert.equal(bal(e.L,'1210'),12000);assert.equal(bal(e.L,'1219'),-11000);assert.equal(bal(e.L,'5400'),11000);assert.equal(bal(e.L,'1110'),-12000);
  assert.equal(e.L.balanceSheet(tb).balanced,true)});
test('كل قيد مشتق متوازن، ومفاتيحه فريدة وحتمية (لا تكرار عند إعادة الاشتقاق)',()=>{
  const e=mk();add(e);add(e,{name:'ثلاجة',cost:3333.33,lifeYears:2.5,fund:'bank'});
  const a=e.L.entries().list,b=e.L.entries().list;
  assert.equal(a.length,new Set(a.map(x=>x.key)).size);assert.deepEqual(a.map(x=>x.key),b.map(x=>x.key));
  a.forEach(x=>assert.ok(Math.abs(x.lines.reduce((s,l)=>s+l.d-l.c,0))<0.005,x.key));assert.equal(e.L.entries().warn.length,0)});
test('التمويل بالآجل يثبت التزام المورد، ورأس المال يرفع حقوق الملكية',()=>{
  const e=mk();add(e,{fund:'ap',name:'أ',cost:500});add(e,{fund:'capital',name:'ب',cost:700});
  assert.equal(bal(e.L,'2110'),-500);assert.equal(bal(e.L,'3100'),-700)});
test('بيع أصل بربح: يُرحَّل المجمّع والمتحصل والربح ويُغلق الأصل ومجمعه',()=>{
  const e=mk(),a=add(e);const r=e.A.dispose(a.id,{mode:'sale',proceeds:3000,to:'cash',date:'2026-11-05',reason:'تجديد'});
  assert.ok(!r.err,r.err);assert.equal(r.book,1000);assert.equal(r.gl,2000);
  assert.equal(bal(e.L,'1210'),0);assert.equal(bal(e.L,'1219'),0);assert.equal(bal(e.L,'5450'),-2000);
  const t=e.L.totals(e.L.tb());assert.equal(t.debit,t.credit)});
test('بيع بخسارة وشطب: 5450 مدين بالخسارة، والقيد متوازن',()=>{
  const e=mk(),a=add(e),b=add(e,{name:'ج'});
  e.A.dispose(a.id,{mode:'sale',proceeds:400,to:'bank',date:'2026-11-05',reason:'بيع'});
  e.A.dispose(b.id,{mode:'writeoff',date:'2026-11-06',reason:'تلف'});
  assert.equal(bal(e.L,'5450'),600+1000);const t=e.L.totals(e.L.tb());assert.equal(t.debit,t.credit);
  assert.equal(e.L.balanceSheet(e.L.tb()).balanced,true)});
test('بعد الاستبعاد يتوقف الإهلاك ولا يُولَّد قسط لاحق',()=>{
  const e=mk(),a=add(e);e.A.dispose(a.id,{mode:'writeoff',date:'2026-06-10',reason:'تلف'});
  const s=e.A.schedule(a);assert.equal(s[s.length-1].m,'2026-06');assert.ok(!e.L.entries().list.some(x=>x.key==='dep:'+a.id+':2026-07'))});
test('أصل مستبعد لا يُعدَّل، ولا استبعاد مرتين، والتراجع يتطلب سببًا ويزيل قيد الاستبعاد',()=>{
  const e=mk(),a=add(e);e.A.dispose(a.id,{mode:'writeoff',date:'2026-06-10',reason:'x'});
  assert.ok(e.A.save(a.id,Object.assign({},base,{note:'n'})).err);assert.ok(e.A.dispose(a.id,{mode:'writeoff',reason:'y'}).err);
  assert.ok(e.A.undispose(a.id,'').err);assert.ok(!e.A.undispose(a.id,'خطأ إدخال').err);
  assert.ok(!e.L.entries().list.some(x=>x.key==='assetdisp:'+a.id));assert.equal(bal(e.L,'1210'),12000)});
test('إقفال الفترة: لا ربط بتاريخ مقفل، ولا تعديل أرقام أصل مربوط، ولا استبعاد داخل الفترة',()=>{
  const e=mk({lock:'2026-03-31'});assert.ok(e.A.save('',Object.assign({},base,{date:'2026-02-01'})).err);
  const ok=e.A.save('',Object.assign({},base,{date:'2026-02-01',fund:'none'}));assert.ok(!ok.err);
  const e2=mk(),a=add(e2);const e3=mk({lock:'2026-03-31'});e3.db.assets.push(Object.assign({},a));
  assert.ok(e3.A.save(a.id,Object.assign({},base,{cost:9999})).err);
  assert.ok(e3.A.dispose(a.id,{mode:'writeoff',date:'2026-03-01',reason:'x'}).err)});
test('التحقق من المدخلات: تكلفة/عمر/خردة/تاريخ مستقبلي/اسم مكرر',()=>{
  const e=mk();for(const v of[{cost:0},{lifeYears:0},{lifeYears:101},{salvage:99999},{date:'2027-01-01'},{name:''},{fund:'zzz'}])assert.ok(e.A.save('',Object.assign({},base,v)).err,JSON.stringify(v));
  add(e);assert.ok(e.A.save('',base).err)});
test('الصلاحية: غير المدير لا يحفظ ولا ينقل ولا يستبعد',()=>{
  const e=mk({admin:false});assert.ok(e.A.save('',base).err);
  const m=mk(),a=add(m);m.ctx.isAdmin=()=>false;
  assert.ok(m.A.move(a.id,{to:'x'}).err);assert.ok(m.A.dispose(a.id,{mode:'writeoff',reason:'x'}).err)});
test('نقل الأصل سجل إلحاقي بلا أثر محاسبي',()=>{
  const e=mk(),a=add(e,{loc:'مخزن',custodian:'علي'});const before=JSON.stringify(e.L.tb());
  assert.ok(!e.A.move(a.id,{to:'فرع 2',custodian:'سالم',date:'2026-09-01'}).err);
  assert.equal(JSON.stringify(e.L.tb()),before);assert.equal(a.moves.length,2);
  assert.ok(e.A.move(a.id,{to:'فرع 2',custodian:'سالم'}).err);assert.ok(e.A.move(a.id,{to:'ز',date:'2026-08-01'}).err)});
test('التدفقات النقدية: الشراء استثماري والبيع استثماري، والتسوية متطابقة',()=>{
  const e=mk(),a=add(e);e.A.dispose(a.id,{mode:'sale',proceeds:3000,to:'cash',date:'2026-11-05',reason:'x'});
  const c=e.L.cashFlow();assert.equal(c.invTotal,-9000);assert.equal(c.opTotal,0);assert.equal(c.reconciled,true)});
test('أصول قديمة بلا fund تعمل كما كانت ولا تدخل الدفتر',()=>{
  const e=mk();e.db.assets.push({id:'old',name:'قديم',cost:600,date:'2026-01-01',lifeYears:1,salvage:0});
  assert.equal(e.A.posted(e.db.assets[0]),false);assert.equal(e.L.tb().length,0);assert.equal(e.A.calc(e.db.assets[0]).acc,550)});
