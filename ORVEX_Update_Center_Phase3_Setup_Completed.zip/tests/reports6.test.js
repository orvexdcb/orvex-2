const test=require('node:test'),assert=require('node:assert/strict');
const {mkLedger,mkSale,shop}=require('./helpers');
const r2=n=>Math.round(n*100)/100;
const j=o=>JSON.stringify(o);
function mk(){const db=shop();db.customers=[{id:'c1',name:'عميل 1',balance:0},{id:'c2',name:'عميل 2',balance:0}];db.suppliers=[{id:'s1',name:'مورد',balance:0}];
  db.preturns=[];db.products=[{id:'a',name:'أ',stock:100,cost:4,price:6,wh:{}}];return db}

/* ===== أعمار الديون ===== */
test('أعمار العملاء: التوزيع على الفترات، والدفعة تسدّد الأقدم أولًا، والمجموع يطابق الرصيد',()=>{
  const db=mk();
  db.sales.push({id:'s1',no:'I1',cid:'c1',date:'2026-07-01',total:100,paid:0,method:'credit'},   /* 133 يومًا */
                {id:'s2',no:'I2',cid:'c1',date:'2026-09-20',total:50,paid:0,method:'credit'},    /* 51 */
                {id:'s3',no:'I3',cid:'c1',date:'2026-11-05',total:30,paid:10,method:'credit'});  /* 5 → متبقي 20 */
  db.payments.push({id:'p1',type:'c',pid:'c1',amount:60,date:'2026-11-08'});   /* يسدّد I1 (100→40) فقط */
  db.customers[0].balance=r2(100+50+20-60);
  const L=mkLedger(db),a=L.aging('c','2026-11-10');
  assert.equal(j(a.labels),j(['0-30','31-60','61-90','90+']));
  const r=a.rows.find(x=>x.id==='c1');
  assert.equal(j(r.buckets),j([20,50,0,40]));assert.equal(r.docs,110);assert.equal(r.balance,110);assert.equal(r.unallocated,0);
  assert.equal(a.docsTotal,110)});
test('أعمار العملاء: رصيد افتتاحي بلا مستندات يظهر كـ«غير مفسَّر» لا يُخفى، ودفعة زائدة تظهر سالبة',()=>{
  const db=mk();db.customers[0].balance=500;db.customers[1].balance=-25;
  db.payments.push({id:'p',type:'c',pid:'c2',amount:25,date:'2026-11-01'});
  const a=mkLedger(db).aging('c','2026-11-10');
  assert.equal(a.rows.find(x=>x.id==='c1').unallocated,500);assert.equal(a.rows.find(x=>x.id==='c2').unallocated,-25);
  assert.equal(a.balanceTotal,475)});
test('أعمار العملاء: المبيعات الملغاة والمستقبلية (بعد تاريخ التقرير) لا تُحسب، ومرتجع «على الرصيد» يُسدّد الأقدم',()=>{
  const db=mk();
  db.sales.push({id:'x1',no:'I1',cid:'c1',date:'2026-10-01',total:100,paid:0,method:'credit'},{id:'x2',no:'I2',cid:'c1',date:'2026-10-02',total:999,paid:0,void:true},{id:'x3',no:'I3',cid:'c1',date:'2026-12-01',total:77,paid:0});
  db.returns.push({id:'r1',cid:'c1',date:'2026-10-20',total:40,method:'balance'});db.customers[0].balance=60;
  const r=mkLedger(db).aging('c','2026-11-10').rows[0];assert.equal(r.docs,60);assert.equal(r.balance,60);assert.equal(j(r.buckets),j([0,60,0,0]))});
test('أعمار الموردين: مشتريات آجلة + دفعة + مرتجع شراء على الذمة',()=>{
  const db=mk();
  db.purchases.push({id:'o1',no:'P1',sid:'s1',date:'2026-08-01',total:300,paid:0},{id:'o2',no:'P2',sid:'s1',date:'2026-11-01',total:200,paid:50});
  db.payments.push({id:'q',type:'s',pid:'s1',amount:100,date:'2026-11-02'});
  db.preturns.push({id:'pr',sid:'s1',date:'2026-11-03',apPart:40,total:40});
  db.suppliers[0].balance=300+150-100-40;
  const a=mkLedger(db).aging('s','2026-11-10'),r=a.rows[0];
  assert.equal(r.docs,310);assert.equal(r.balance,310);assert.equal(j(r.buckets),j([150,0,0,160]))});

/* ===== التدفقات النقدية ===== */
test('التدفقات النقدية: تُصنَّف تشغيلي/استثماري/تمويلي، والرصيد الافتتاحي + الصافي = الختامي، وتطابق رصيد الصندوق في الميزان',()=>{
  const db=mk();
  db.purchases.push({id:'o1',no:'P1',sid:'s1',date:'2026-10-01',total:1000,paid:1000,method:'cash'});          /* خارج الفترة: يدخل في الافتتاحي */
  db.sales.push({id:'v1',no:'I1',date:'2026-11-02',total:200,paid:200,method:'cash',cost:80},{id:'v2',no:'I2',cid:'c1',date:'2026-11-03',total:100,paid:25,method:'credit',cost:40});
  db.expenses.push({id:'e1',date:'2026-11-04',amount:30,cat:'إيجار',method:'cash'});
  db.payments.push({id:'p1',type:'c',pid:'c1',amount:15,date:'2026-11-05'});
  const L=mkLedger(db);
  /* قيد رأس مال (تمويلي) افتتاحي قبل الفترة وقيد مساهمة داخلها */
  assert.ok(L.jeCreate('2026-10-01','رأس مال',[{a:'a1110',d:1000,c:0},{a:'a3100',d:0,c:1000}]).ok);
  assert.ok(L.jeCreate('2026-11-06','زيادة رأس مال',[{a:'a1110',d:500,c:0},{a:'a3100',d:0,c:500}]).ok);
  const cf=L.cashFlow('2026-11-01','2026-11-30');
  assert.equal(cf.finTotal,500);assert.equal(cf.invTotal,0);
  assert.equal(cf.opening,0);                                  /* 1000 شراء نقدي − 1000 رأس مال */
  assert.equal(cf.opTotal,r2(200+25+15-30));
  assert.equal(cf.net,r2(cf.opTotal+cf.finTotal));assert.equal(cf.closing,r2(cf.opening+cf.net));assert.ok(cf.reconciled);
  /* النقدية = الصندوق + كل حسابات البنك (الدفعة المقدمة على فاتورة آجلة تُرحَّل حاليًا إلى «البنك العام» 1120 — سلوك قائم في accounting.js cashKey) */
  const tb=L.tb('','2026-11-30'),cashAll=r2(tb.filter(r=>r.id==='a1110'||r.id==='a1120'||/^bk_/.test(r.id)).reduce((a,r)=>a+r.balance,0));assert.equal(cashAll,cf.closing)});
test('التدفقات النقدية: البيع الآجل بالكامل لا يُظهر أي تدفق، والمبالغ البنكية تدخل ضمن النقدية',()=>{
  const db=mk();db.sales.push({id:'v',no:'I',cid:'c1',date:'2026-11-02',total:100,paid:0,method:'credit',cost:40});
  let cf=mkLedger(db).cashFlow('2026-11-01','2026-11-30');assert.equal(cf.net,0);assert.equal(cf.closing,0);assert.ok(cf.reconciled);
  const db2=mk();const L=mkLedger(db2);assert.ok(L.bankAdd('مصرف',['card']).ok);
  db2.sales.push({id:'w',no:'I',date:'2026-11-02',total:80,paid:80,method:'card',cost:0});
  cf=L.cashFlow('2026-11-01','2026-11-30');assert.equal(cf.net,80);assert.ok(cf.reconciled)});
