const test=require('node:test'),assert=require('node:assert/strict'),vm=require('vm');
const {read}=require('./helpers');
/* inventory2.js غير مُصدَّر (يعتمد DOM)، لذا نستخرج دالة fefo الحقيقية من المصدر دون تعديله */
function loadFefo(){
  const src=read('inventory2.js'),i=src.indexOf('function fefo(p,q)');assert.ok(i>=0,'fefo غير موجودة');
  let j=src.indexOf('\nfunction serialModal',i);assert.ok(j>i);
  const ctx={r2:n=>Math.round(+n*100)/100};vm.createContext(ctx);
  vm.runInContext(src.slice(i,j)+';this.fefo=fefo',ctx);return ctx.fefo}
const fefo=loadFefo();
const prod=()=>({batches:[{no:'B3',qty:5,exp:'2027-03-01'},{no:'B1',qty:3,exp:'2026-12-01'},{no:'B2',qty:4,exp:'2027-01-15'},{no:'B0',qty:0,exp:'2026-01-01'},{no:'BN',qty:2}]});
test('8) FEFO: الصرف من أقرب انتهاء أولًا، والدفعة الفارغة تُتجاهل، وبلا تاريخ تأتي أخيرًا',()=>{
  const p=prod(),r=fefo(p,10);
  assert.equal(JSON.stringify(r.used.map(x=>[x.no,x.q])),JSON.stringify([['B1',3],['B2',4],['B3',3]]));assert.equal(r.short,0);
  assert.equal(p.batches.find(b=>b.no==='B3').qty,2);assert.equal(p.batches.find(b=>b.no==='BN').qty,2)});
test('FEFO: عند نقص الدفعات يُبلَّغ بالعجز ولا تصير كمية سالبة',()=>{
  const p=prod(),r=fefo(p,20);assert.equal(r.short,6);/* المتاح 14 (5+3+4+2) والمطلوب 20 */assert.ok(p.batches.every(b=>b.qty>=0))});
test('FEFO: كسور الكميات لا تترك بقايا عائمة',()=>{
  const p={batches:[{no:'A',qty:0.3,exp:'2026-12-01'}]};const r=fefo(p,0.1);assert.equal(p.batches[0].qty,0.2);assert.equal(r.short,0)});
test('غطاء اختبار: كل ملفات المخزون تُحمَّل نحويًا',()=>{
  for(const f of['inventory.js','inventory2.js','inventory3.js','purchases.js']){new vm.Script(read(f),{filename:f})}});
