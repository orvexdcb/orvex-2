const fs=require('fs'),vm=require('vm'),path=require('path');
const root=path.join(__dirname,'..');
exports.root=root;
exports.read=f=>fs.readFileSync(path.join(root,f),'utf8');
exports.acct=()=>require(path.join(root,'accounting.js'));
/* يحمّل ledger.js الحقيقي في سياق معزول مع db وهمي؛ كل استدعاء = "محل" مستقل (عزل بيانات) */
exports.mkLedger=function(db,opt){
  opt=opt||{};let n=0;
  const ctx={db,console,uid:()=>'id'+(++n),today:()=>opt.today||'2026-11-10',
    can:()=>true,isAdmin:()=>opt.admin!==false,curUser:()=>({name:'tester'}),orvexLog(){}};
  ctx.globalThis=ctx;vm.createContext(ctx);
  ctx.orvexAcct=exports.acct();
  vm.runInContext(exports.read('ledger.js'),ctx,{filename:'ledger.js'});
  return ctx.ORVEX_LED;
};
exports.shop=()=>({sales:[],returns:[],purchases:[],expenses:[],payments:[],closings:[],stocktakes:[],journals:[],coa:[],bankAccts:[],settings:{}});
/* يحمّل inventory3.js الحقيقي (تحويلات/جرد/مخازن) في سياق معزول مع db وهمي وصلاحيات قابلة للتحكم */
exports.mkInv3=function(db,opt){
  opt=opt||{};let n=0;
  const ctx={db,console,uid:()=>'u'+(++n)+Math.random().toString(36).slice(2,6),today:()=>'2026-11-10',
    can:()=>opt.can!==false,isAdmin:()=>opt.admin!==false,curUser:()=>({name:opt.user||'tester'}),
    num:v=>{const x=parseFloat(v);return isFinite(x)?x:0},r2:v=>Math.round((parseFloat(v)||0)*100)/100,
    prod:id=>db.products.find(p=>p.id===id),toast(){},save(){},render(){},state:{}};
  ctx.window=ctx;ctx.globalThis=ctx;vm.createContext(ctx);
  vm.runInContext(exports.read('inventory3.js'),ctx,{filename:'inventory3.js'});
  return ctx.ORVEX_INV3;
};
/* يحمّل inventory2.js الحقيقي (باركودات/وحدات/تشغيلات) مع بدائل بسيطة لدوال البيع/الواجهة العامة التي يغلّفها.
   أي اسم عام ناقص يُعرَّف تلقائيًا كدالة فارغة (تُسجَّل في ctx.__stubs) ثم يُعاد التحميل في سياق نظيف. */
exports.mkInv2=function(db){
  const stubs=[];
  for(let attempt=0;attempt<60;attempt++){
    const cart=[];const ctx={db,console,state:{cart},today:()=>'2026-11-10',can:()=>true,isAdmin:()=>true,curUser:()=>({name:'t'}),
      num:v=>{const x=parseFloat(v);return isFinite(x)?x:0},r2:v=>Math.round((parseFloat(v)||0)*100)/100,
      prod:id=>db.products.find(p=>p.id===id),toast(){},save(){},render(){},uid:()=>'u'+Math.random().toString(36).slice(2,8),
      $:()=>null,esc:s=>s,jsq:s=>s,money:v=>v,fdate:s=>s,modal(){},
      matchProds:q=>[],doEntry:q=>{ctx.__fallback=q},productForm(){},saveProduct(){},finalize(){},posRender(){},
      addCart:(pid,q)=>{const p=db.products.find(x=>x.id===pid);cart.push({pid,qty:q||1,price:p.price,cost:p.cost})}};
    stubs.forEach(n=>{ctx[n]=function(){}});ctx.__stubs=stubs;
    ctx.window=ctx;ctx.globalThis=ctx;vm.createContext(ctx);
    try{vm.runInContext(exports.read('inventory2.js'),ctx,{filename:'inventory2.js'});return ctx}
    catch(e){const m=/^(\w+) is not defined/.exec(e.message);if(!m)throw e;stubs.push(m[1])}
  }
  throw new Error('inventory2.js: أسماء عامة ناقصة كثيرة: '+stubs.join(','));
};
/* يحمّل pos.js الحقيقي + inventory2.js + inventory3.js بنفس ترتيب index.html في سياق واحد،
   فيمر البيع عبر سلسلة finalize الحقيقية (السيريال/التشغيلات ثم المخزن غير الرئيسي). أي اسم عام ناقص يُعرَّف تلقائيًا. */
exports.mkSale=function(db,opt){
  opt=opt||{};const stubs=[];
  for(let attempt=0;attempt<120;attempt++){
    let n=0;const msgs=[],ls={};
    const ctx={db,console,state:{cart:[]},today:()=>'2026-11-10',can:()=>opt.can!==false,isAdmin:()=>opt.admin!==false,curUser:()=>({name:'cashier'}),
      num:v=>{const x=parseFloat(v);return isFinite(x)?x:0},r2:v=>Math.round((parseFloat(v)||0)*100)/100,
      sum:(a,f)=>a.reduce((s,x)=>s+f(x),0),
      prod:id=>db.products.find(p=>p.id===id),cust:id=>(db.customers||[]).find(c=>c.id===id),
      uid:()=>'s'+(++n)+Math.random().toString(36).slice(2,6),nextNo:()=>'INV-'+(db.sales.length+1),
      toast:m=>msgs.push(m),save(){},render(){},posRender(){},showInvoice(){},noInv:()=>true,closeModal(){},modal(){},
      $:()=>null,esc:s=>s,jsq:s=>s,money:v=>v,fdate:s=>s,localStorage:{getItem:k=>(k in ls?ls[k]:null),setItem:(k,v)=>{ls[k]=String(v)},removeItem:k=>{delete ls[k]}},
      matchMedia:()=>({matches:false}),setInterval(){return 0},clearInterval(){},document:{addEventListener(){},querySelectorAll:()=>[],createElement:()=>({}),body:{appendChild(){}}},
      confirm:()=>true,askConfirm(){}};
    stubs.forEach(s=>{ctx[s]=function(){}});
    ctx.window=ctx;ctx.globalThis=ctx;ctx.__msgs=msgs;vm.createContext(ctx);
    try{['pos.js','inventory2.js','inventory3.js'].forEach(f=>vm.runInContext(exports.read(f),ctx,{filename:f}));return ctx}
    catch(e){const m=/^(\w+) is not defined/.exec(e.message);if(!m)throw e;stubs.push(m[1])}
  }
  throw new Error('pos.js: أسماء عامة ناقصة كثيرة: '+stubs.join(','));
};
