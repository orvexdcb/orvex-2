const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const root = path.resolve(__dirname, '../..');

function signed(payload, secret) {
  const body = Buffer.from(JSON.stringify(payload)).toString('base64url');
  const sig = crypto.createHmac('sha256', secret).update(body).digest('base64url');
  return `${body}.${sig}`;
}

test('Vercel routes immutable release paths through same-origin proxy', () => {
  const cfg = JSON.parse(fs.readFileSync(path.join(root, 'vercel.json'), 'utf8'));
  assert.ok(cfg.rewrites.some(x => x.source.includes('/__orvex/releases/:releaseId/:path*') && x.destination.includes('/api/release-proxy')));
  const proxy = fs.readFileSync(path.join(root, 'api/release-proxy.js'), 'utf8');
  assert.match(proxy, /orvex_release_ticket/);
  assert.match(proxy, /payload\.releaseId !== releaseId/);
  assert.match(proxy, /payload\.deploymentUrl/);
});

test('release ticket HMAC rejects invalid, expired and non-Vercel deployments', () => {
  const secret = 'test-secret-with-at-least-32-characters-long';
  process.env.ORVEX_RELEASE_TICKET_SECRET = secret;
  const { verifyTicket } = require('../../api/_release-ticket');
  const base = { sub: 'user-1', tenantType: 'shop', tenantId: 'shop-1', releaseId: 'release-1', version: '1.2.3', deploymentUrl: 'https://orvex-abc123.vercel.app', exp: Math.floor(Date.now() / 1000) + 120 };
  const token = signed(base, secret);
  assert.equal(verifyTicket(token).releaseId, 'release-1');
  assert.equal(verifyTicket(token + 'x'), null);
  assert.equal(verifyTicket(signed({ ...base, exp: 1 }, secret)), null);
  assert.equal(verifyTicket(signed({ ...base, deploymentUrl: 'https://example.com' }, secret)), null);
});

test('ticket endpoint sets an HttpOnly same-origin path-scoped cookie', async () => {
  const secret = 'test-secret-with-at-least-32-characters-long';
  process.env.ORVEX_RELEASE_TICKET_SECRET = secret;
  process.env.SUPABASE_URL = 'https://project.supabase.co';
  process.env.SUPABASE_ANON_KEY = 'public-anon-key';
  const oldFetch = global.fetch;
  global.fetch = async () => ({ ok: true, json: async () => ({ id: 'user-1' }) });
  const handler = require('../../api/release-ticket');
  const payload = { sub: 'user-1', tenantType: 'shop', tenantId: 'shop-1', releaseId: 'release-2', version: '1.0.0', deploymentUrl: 'https://orvex-stage.vercel.app', exp: Math.floor(Date.now() / 1000) + 120 };
  const req = { method: 'POST', headers: { origin: 'https://orvex-pi.vercel.app', host: 'orvex-pi.vercel.app', authorization: 'Bearer user-access-token' }, body: { ticket: signed(payload, secret) } };
  const headers = {}; let result;
  const res = { setHeader(k, v) { headers[k] = v; }, status(n) { this.code = n; return this; }, json(v) { result = v; return this; } };
  try { await handler(req, res); } finally { global.fetch = oldFetch; }
  assert.equal(res.code, 200);
  assert.match(headers['Set-Cookie'], /HttpOnly/);
  assert.match(headers['Set-Cookie'], /Path=\/__orvex\/releases\/release-2\//);
  assert.equal(result.path, '/__orvex/releases/release-2/index.html');
});

test('login checks only the server-published manifest and requests a signed ticket', () => {
  const server = fs.readFileSync(path.join(root, 'server.js'), 'utf8');
  assert.match(server, /action:'manifest'/);
  assert.match(server, /action:'issue_ticket'/);
  assert.match(server, /\/api\/release-ticket/);
  assert.match(server, /window\.ORVEX_BUILD_VERSION/);
  assert.match(server, /SB\.dirty\|\|SB\.busy/);
});

test('release Edge Function permits tenant manifest/ticket checks but founder-gates management', () => {
  const ts = fs.readFileSync(path.join(root, 'supabase/functions/orvex-release-center/index.ts'), 'utf8');
  assert.match(ts, /!\['manifest','issue_ticket'\]\.includes\(action\)/);
  assert.match(ts, /ORVEX_RELEASE_TICKET_SECRET/);
  assert.match(ts, /ORVEX_RELEASE_ROUTING_ENABLED/);
  assert.match(ts, /action === 'issue_ticket'/);
  assert.match(ts, /action === 'publish'/);
  assert.match(ts, /status: 'published'/);
  assert.match(ts, /status: 'rolled_back'/);
});

test('release navigation preserves the current origin and uses automatic fallback for rollback', () => {
  const server = fs.readFileSync(path.join(root, 'server.js'), 'utf8');
  assert.match(server, /location\.assign\(ready\.path\)/);
  assert.match(server, /location\.assign\('\/'\)/);
  assert.match(server, /compareReleaseVersions/);
  assert.match(server, /5\*60\*1000/);
  assert.match(server, /__orvexReleasePoll/);
  assert.match(server, /if\(rollback\)toast/);
  assert.match(server, /Authorization':'Bearer '\+await tok\(\)/);
});

test('release build script stamps the version and isolates Service Worker caches', () => {
  const script = fs.readFileSync(path.join(root, 'scripts/build-release.mjs'), 'utf8');
  assert.match(script, /ORVEX_BUILD_VERSION/);
  assert.match(script, /const VER=.*orvex-release-\$\{version\}/);
  assert.match(script, /orvex-release\.zip/);
  assert.match(script, /sha256/);
  const sw = fs.readFileSync(path.join(root, 'sw.js'), 'utf8');
  assert.match(sw, /orvex-root-/);
  assert.match(sw, /x\.startsWith\('orvex-root-'\)/);
  assert.match(sw, /CLEAN_ROOT_CACHES\?caches\.keys/);
});

test('publish button requires both Supabase routing enablement and Vercel runtime secrets', () => {
  const ui = fs.readFileSync(path.join(root, 'update-center.js'), 'utf8');
  const health = fs.readFileSync(path.join(root, 'api/release-routing-health.js'), 'utf8');
  assert.match(ui, /release-routing-health/);
  assert.match(ui, /r\.distribution_enabled===true&&routing/);
  assert.match(health, /ORVEX_RELEASE_TICKET_SECRET/);
  assert.match(health, /SUPABASE_URL/);
  assert.match(health, /SUPABASE_ANON_KEY/);
  assert.match(health, /SUPABASE_PUBLISHABLE_KEY/);
  assert.match(health, /orvex-release-monitor/);
});


test('proxy reports upstream failures and the monitor quarantines after distinct-user threshold', () => {
  const proxy = fs.readFileSync(path.join(root, 'api/release-proxy.js'), 'utf8');
  const monitor = fs.readFileSync(path.join(root, 'supabase/functions/orvex-release-monitor/index.ts'), 'utf8');
  assert.match(proxy, /orvex-release-monitor/);
  assert.match(proxy, /report && report\.quarantined/);
  assert.match(monitor, /proxy_asset_failure/);
  assert.match(monitor, /affectedUsers\.size >= 3/);
  assert.match(monitor, /status: 'quarantined'/);
  assert.match(monitor, /automatic_quarantine/);
  assert.match(monitor, /req\.method === 'GET'/);
});

test('same-origin release proxy serves only a valid path-scoped ticket', async () => {
  const secret = 'test-secret-with-at-least-32-characters-long';
  process.env.ORVEX_RELEASE_TICKET_SECRET = secret;
  const payload = { sub: 'user-1', tenantType: 'shop', tenantId: 'shop-1', releaseId: 'release-3', version: '1.0.0', deploymentUrl: 'https://orvex-stage.vercel.app', exp: Math.floor(Date.now() / 1000) + 120 };
  const token = signed(payload, secret);
  const oldFetch = global.fetch;
  global.fetch = async (url) => ({ url: 'https://orvex-stage.vercel.app/server.js', status: 200, headers: new Headers({ 'content-type': 'application/javascript' }), arrayBuffer: async () => Buffer.from('window.releaseLoaded=true;') });
  const handler = require('../../api/release-proxy');
  const headers = {}; let body = ''; const res = { setHeader(k,v){headers[k]=v;}, status(n){this.code=n;return this;}, send(v){body=String(v);return this;}, end(v){body=String(v||'');return this;}, redirect(n,p){this.code=n;this.location=p;return this;} };
  try { await handler({ method:'GET', query:{releaseId:'release-3',path:'server.js'}, headers:{cookie:'orvex_release_ticket='+encodeURIComponent(token)} }, res); }
  finally { global.fetch = oldFetch; }
  assert.equal(res.code,200);
  assert.match(body,/releaseLoaded/);
  assert.match(headers['Cache-Control'],/private/);
});

test('proxy sends 5xx evidence to monitor and redirects when automatic quarantine trips', async () => {
  const secret = 'test-secret-with-at-least-32-characters-long';
  process.env.ORVEX_RELEASE_TICKET_SECRET = secret;
  process.env.SUPABASE_URL = 'https://project.supabase.co';
  const payload = { sub: 'user-3', tenantType: 'shop', tenantId: 'shop-3', releaseId: 'release-4', version: '1.0.0', deploymentUrl: 'https://orvex-stage.vercel.app', exp: Math.floor(Date.now() / 1000) + 120 };
  const token = signed(payload, secret); const oldFetch = global.fetch; let reported = false;
  global.fetch = async (url) => {
    if (String(url).includes('orvex-release-monitor')) { reported = true; return new Response(JSON.stringify({ok:true,quarantined:true}), {status:200,headers:{'content-type':'application/json'}}); }
    return { url:'https://orvex-stage.vercel.app/index.html', status:500, headers:new Headers({'content-type':'text/html'}), arrayBuffer:async()=>Buffer.from('error') };
  };
  const handler = require('../../api/release-proxy');
  const res = { headers:{}, setHeader(k,v){this.headers[k]=v;}, status(n){this.code=n;return this;}, send(v){this.body=v;return this;}, end(v){this.body=v;return this;}, redirect(n,p){this.code=n;this.location=p;return this;} };
  try { await handler({ method:'GET', query:{releaseId:'release-4',path:'index.html'}, headers:{cookie:'orvex_release_ticket='+encodeURIComponent(token),accept:'text/html'} }, res); }
  finally { global.fetch = oldFetch; }
  assert.equal(reported,true);
  assert.equal(res.code,302);
  assert.equal(res.location,'/');
});

test('founder center exposes an immutable audit trail for release operations', () => {
  const ts = fs.readFileSync(path.join(root, 'supabase/functions/orvex-release-center/index.ts'), 'utf8');
  const ui = fs.readFileSync(path.join(root, 'update-center.js'), 'utf8');
  assert.match(ts, /from\('orvex_release_events'\)\.select/);
  assert.match(ts, /events: events \|\| \[\]/);
  assert.match(ui, /سجل العمليات والتدقيق/);
  assert.match(ui, /automatic_quarantine/);
  assert.match(ui, /release_rolled_back/);
});


test('only the HMAC-protected monitor function disables platform JWT verification', () => {
  const config = fs.readFileSync(path.join(root, 'supabase/config.toml'), 'utf8');
  const monitor = fs.readFileSync(path.join(root, 'supabase/functions/orvex-release-monitor/index.ts'), 'utf8');
  assert.match(config, /\[functions\.orvex-release-monitor\]/);
  assert.match(config, /verify_jwt = false/);
  assert.match(monitor, /x-orvex-monitor-secret/);
  assert.match(monitor, /crypto\.subtle\.verify/);
});

test('release proxy refuses cross-origin redirects before making a second request', async () => {
  const { fetchReleaseAsset } = require('../../api/release-proxy');
  const oldFetch = global.fetch;
  let calls = 0;
  global.fetch = async () => {
    calls++;
    return new Response(null, { status: 302, headers: { location: 'https://169.254.169.254/latest/meta-data/' } });
  };
  try {
    await assert.rejects(
      fetchReleaseAsset('https://orvex-stage.vercel.app/app.js', {}, 'GET'),
      /release_redirect_origin_rejected/
    );
  } finally { global.fetch = oldFetch; }
  assert.equal(calls, 1, 'external redirect target must never be fetched');
});

test('release package builder excludes environment and Vercel credential files', () => {
  const os = require('node:os');
  const cp = require('node:child_process');
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'orvex-release-build-'));
  try {
    fs.mkdirSync(path.join(tmp, 'scripts'), { recursive: true });
    fs.mkdirSync(path.join(tmp, '.vercel'), { recursive: true });
    fs.copyFileSync(path.join(root, 'scripts/build-release.mjs'), path.join(tmp, 'scripts/build-release.mjs'));
    fs.copyFileSync(path.join(root, 'sw.js'), path.join(tmp, 'sw.js'));
    fs.writeFileSync(path.join(tmp, 'index.html'), '<!doctype html>');
    fs.writeFileSync(path.join(tmp, '.env.production'), 'SUPABASE_SERVICE_ROLE_KEY=must-not-ship');
    fs.writeFileSync(path.join(tmp, '.vercel/project.json'), '{"token":"must-not-ship"}');
    cp.execFileSync(process.execPath, [path.join(tmp, 'scripts/build-release.mjs')], {
      cwd: tmp, env: { ...process.env, ORVEX_RELEASE_VERSION: '9.8.7' }, stdio: 'pipe'
    });
    const listing = cp.execFileSync('unzip', ['-Z1', path.join(tmp, 'orvex-release.zip')], { encoding: 'utf8' });
    assert.match(listing, /index\.html/);
    assert.doesNotMatch(listing, /\.env\.production|\.vercel\/project\.json/);
  } finally { fs.rmSync(tmp, { recursive: true, force: true }); }
});
