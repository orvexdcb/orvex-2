const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '../..');

test('release migration is additive and does not touch business tables', () => {
  const sql = fs.readFileSync(path.join(root,'supabase/migrations/20261111180000_orvex_release_center.sql'),'utf8');
  for (const name of ['orvex_releases','orvex_release_targets','orvex_release_events']) assert.match(sql,new RegExp('create table if not exists public\\.'+name));
  assert.match(sql,/enable row level security/);
  assert.match(sql,/revoke all on public\.orvex_releases from anon, authenticated/);
  assert.match(sql,/orvex_release_events_monitor_idx/);
  assert.match(sql,/revoke all on function public\.orvex_release_events_immutable\(\) from public, anon, authenticated/);
  assert.doesNotMatch(sql,/drop table|truncate|delete from public\.(sales|products|records)/i);
});

test('release function verifies authenticated founder server-side and keeps publishing fail-closed', () => {
  const ts = fs.readFileSync(path.join(root,'supabase/functions/orvex-release-center/index.ts'),'utf8');
  assert.match(ts,/auth\.getUser\(\)/);
  assert.match(ts,/const isFounder = profile\.role === 'founder'/);
  assert.match(ts,/!\['manifest','issue_ticket'\]\.includes\(action\)/);
  assert.match(ts,/distribution_not_configured/);
  assert.match(ts,/tenant_manifest_fallback/);
});

test('update center is only linked from designer hub and shows no public update before release', () => {
  const hub = fs.readFileSync(path.join(root,'designer-hub.js'),'utf8');
  const ui = fs.readFileSync(path.join(root,'update-center.js'),'utf8');
  assert.match(hub,/orvexUpdateCenter/);
  assert.match(ui,/isDesigner\(\)/);
  assert.match(ui,/لا يظهر تحديث لأي جهة إلا بعد اعتماد الإصدار ثم الضغط على «نشر التحديث»/);
});

test('release manifest is tenant-bound and only returns explicitly published targets', () => {
  const ts = fs.readFileSync(path.join(root,'supabase/functions/orvex-release-center/index.ts'),'utf8');
  assert.match(ts,/action === 'manifest'/);
  assert.match(ts,/profile\.shop_id/);
  assert.match(ts,/profile\.role === 'founder' \? 'founder' : 'shop'/);
  assert.match(ts,/\.eq\('status', 'published'\)/);
  assert.match(ts,/t\.target_type === 'all'/);
  assert.match(ts,/t\.excluded === true/);
});

test('release artifact registration verifies immutable Vercel deployment bytes and version', () => {
  const ts = fs.readFileSync(path.join(root,'supabase/functions/orvex-release-center/index.ts'),'utf8');
  assert.match(ts,/orvex-release\.zip/);
  assert.match(ts,/crypto\.subtle\.digest\('SHA-256'/);
  assert.match(ts,/artifactManifest\.version !== release\.version/);
  assert.match(ts,/artifactManifest\.product !== 'ORVEX'/);
  assert.match(ts,/artifact_integrity_or_version_mismatch/);
});

test('staging workflow runs tests and never assigns production domains', () => {
  const workflow = fs.readFileSync(path.join(root,'.github/workflows/orvex-stage-release.yml'),'utf8');
  assert.match(workflow,/workflow_dispatch/);
  assert.match(workflow,/npm test/);
  assert.match(workflow,/vercel pull --yes --environment=production/);
  assert.match(workflow,/vercel build --prod/);
  assert.match(workflow,/vercel deploy --prebuilt --prod --skip-domain/);
  assert.doesNotMatch(workflow,/vercel promote/);
});
