"""اختبار تشغيلي للمسودة supabase/proposed/20261110120000_acct_core.sql على PostgreSQL محلي معزول (pgserver).
لا يتصل بأي قاعدة إنتاج. يحاكي دوال Supabase (my_role/my_shop/...) عبر إعدادات الجلسة.
التشغيل: python3 tests/db/acct_core.dryrun.py"""
import os,sys,tempfile,uuid,pgserver,psycopg
HERE=os.path.dirname(os.path.abspath(__file__));ROOT=os.path.abspath(os.path.join(HERE,'..','..'))
sql=open(os.path.join(ROOT,'supabase/proposed/20261110120000_acct_core.sql'),encoding='utf-8').read()
down=open(os.path.join(ROOT,'supabase/rollback/20261110120000_acct_core_down.sql'),encoding='utf-8').read()
srv=pgserver.get_server(tempfile.mkdtemp());uri=srv.get_uri()
adm=psycopg.connect(uri,autocommit=True)
adm.execute("""
create role anon nologin; create role authenticated nologin;
create schema private; create table public.shops(id uuid primary key default gen_random_uuid(), name text);
create function private.my_role() returns text language sql stable as $$ select nullif(current_setting('t.role',true),'') $$;
create function private.my_shop() returns uuid language sql stable as $$ select nullif(current_setting('t.shop',true),'')::uuid $$;
create function private.my_device_ok() returns boolean language sql stable as $$ select coalesce(nullif(current_setting('t.dev',true),''),'on')='on' $$;
create function private.my_shop_licensed() returns boolean language sql stable as $$ select true $$;
create function private.mall_is_manager() returns boolean language sql stable as $$ select false $$;
grant usage on schema public to authenticated; grant usage on schema private to authenticated;
grant execute on all functions in schema public to authenticated; grant execute on all functions in schema private to authenticated;
""")
adm.execute(sql)
A=adm.execute("insert into shops(name) values('A') returning id").fetchone()[0];B=adm.execute("insert into shops(name) values('B') returning id").fetchone()[0]
res=[]
def check(name,fn):
    try: fn(); res.append((name,True,''))
    except AssertionError as e: res.append((name,False,'assert '+str(e)))
    except Exception as e: res.append((name,False,type(e).__name__+': '+str(e).split('\n')[0]))
def raises(fn,frag):
    try: fn()
    except Exception as e:
        assert frag in str(e),f'خطأ مختلف: {str(e)[:120]}'; return
    raise AssertionError('لم يُرفع خطأ متوقع: '+frag)
def sess(role,shop,dev='on'):
    c=psycopg.connect(uri); c.execute("set role authenticated")
    c.execute("select set_config('t.role',%s,false),set_config('t.shop',%s,false),set_config('t.dev',%s,false)",(role,str(shop) if shop else '',dev)); c.commit(); return c
mA=sess('manager',A);mB=sess('manager',B)
def seed(c,shop): n=c.execute("select public.seed_default_accounts(%s)",(shop,)).fetchone()[0]; c.commit(); return n
def acc(c,shop): return {k:i for k,i in c.execute("select system_key,id from acct_accounts where shop_id=%s",(shop,)).fetchall()}
def je(eid,date,lines,src='sale'):
    import json;return json.dumps({'id':eid,'entry_date':date,'memo':'t','source':src,'source_ref':eid,'created_by':'x','lines':[{'account_id':str(a),'debit':d,'credit':c} for a,d,c in lines]})
def post(c,shop,e):
    r=c.execute("select public.post_journal_entry(%s,%s::jsonb)",(shop,e)).fetchone()[0]; c.commit(); return r
check('بذر الحسابات الافتراضية (22) ومرتين لا يكرر',lambda:(lambda a,b:(a==22 or (_ for _ in ()).throw(AssertionError(a)),b==0 or (_ for _ in ()).throw(AssertionError(b))))(seed(mA,A),seed(mA,A)))
seed(mB,B);aA=acc(mA,A);aB=acc(mB,B)
check('ترحيل قيد متوازن = posted ثم إعادة الإرسال = duplicate دون تكرار الأسطر',lambda:(
  [None for e in [je('sale-1-v1','2026-11-01',[(aA['cash'],115,0),(aA['sales'],0,100),(aA['vat_out'],0,15)])]],
  post(mA,A,je('sale-1-v1','2026-11-01',[(aA['cash'],115,0),(aA['sales'],0,100),(aA['vat_out'],0,15)]))=='posted' or (_ for _ in ()).throw(AssertionError('posted')),
  post(mA,A,je('sale-1-v1','2026-11-01',[(aA['cash'],115,0),(aA['sales'],0,100),(aA['vat_out'],0,15)]))=='duplicate' or (_ for _ in ()).throw(AssertionError('dup')),
  adm.execute("select count(*) from acct_lines where entry_id='sale-1-v1'").fetchone()[0]==3 or (_ for _ in ()).throw(AssertionError('lines'))))
def unbal():
    mA.execute("select public.post_journal_entry(%s,%s::jsonb)",(A,je('bad-1','2026-11-01',[(aA['cash'],100,0),(aA['sales'],0,99)])));mA.commit()
check('قيد غير متوازن يُرفض عند الاعتماد',lambda:(raises(unbal,'ORVEX_UNBALANCED'),mA.rollback()))
check('الرفض لا يترك قيدًا يتيمًا',lambda:adm.execute("select count(*) from acct_entries where id='bad-1'").fetchone()[0]==0 or (_ for _ in ()).throw(AssertionError('orphan')))
def single():
    mA.execute("select public.post_journal_entry(%s,%s::jsonb)",(A,je('bad-2','2026-11-01',[(aA['cash'],100,0)])));mA.commit()
check('قيد بسطر واحد يُرفض',lambda:(raises(single,'ORVEX_UNBALANCED'),mA.rollback()))
check('سطر بمدين ودائن معًا يُرفض',lambda:(raises(lambda:(mA.execute("select public.post_journal_entry(%s,%s::jsonb)",(A,je('bad-3','2026-11-01',[(aA['cash'],5,5),(aA['sales'],0,0)]))),mA.commit()),'check'),mA.rollback()))
check('UPDATE على قيد مرحّل ممنوع حتى للمالك (trigger)',lambda:raises(lambda:adm.execute("update acct_entries set memo='x' where id='sale-1-v1'"),'ORVEX_JOURNAL_IMMUTABLE'))
check('DELETE لقيد مرحّل ممنوع حتى للمالك',lambda:raises(lambda:adm.execute("delete from acct_entries where id='sale-1-v1'"),'ORVEX_JOURNAL_IMMUTABLE'))
check('DELETE/UPDATE للأسطر ممنوع',lambda:(raises(lambda:adm.execute("delete from acct_lines where entry_id='sale-1-v1'"),'ORVEX_JOURNAL_IMMUTABLE'),raises(lambda:adm.execute("update acct_lines set debit=1 where entry_id='sale-1-v1'"),'ORVEX_JOURNAL_IMMUTABLE')))
check('المستخدم المصادَق لا يملك INSERT/UPDATE/DELETE مباشر على الجداول',lambda:[ (raises(lambda:(mA.execute(q),mA.commit()),'permission denied'),mA.rollback()) for q in (f"insert into acct_entries(shop_id,id,entry_date) values('{A}','z','2026-01-01')","delete from acct_entries","update acct_entries set memo='x'")])
def rev1(): r=mA.execute("select public.reverse_journal_entry(%s,'sale-1-v1','rev-sale-1-v1','2026-11-05','u')",(A,)).fetchone()[0];mA.commit();return r
check('عكس القيد: reversed ثم already_reversed، والأصل يبقى، والصافي صفر',lambda:(
  rev1()=='reversed' or (_ for _ in ()).throw(AssertionError('rev')),
  mA.execute("select public.reverse_journal_entry(%s,'sale-1-v1','rev2','2026-11-05','u')",(A,)).fetchone()[0]=='already_reversed' or (_ for _ in ()).throw(AssertionError('again')),
  adm.execute("select count(*) from acct_entries where id='sale-1-v1'").fetchone()[0]==1 or (_ for _ in ()).throw(AssertionError('orig')),
  adm.execute("select sum(debit)-sum(credit), sum(case when account_id=%s then debit-credit else 0 end) from acct_lines where shop_id=%s",(aA['cash'],A)).fetchone()==(0,0) or (_ for _ in ()).throw(AssertionError('net'))))
check('عكس قيد عكسي ممنوع',lambda:raises(lambda:mA.execute("select public.reverse_journal_entry(%s,'rev-sale-1-v1','rr','2026-11-06','u')",(A,)),'ORVEX_BAD_ENTRY'))
mA.rollback()
check('إغلاق الفترة: يمنع الترحيل والعكس في فترة مقفلة ولا يُعاد فتحها',lambda:(
  mA.execute("select public.set_period_lock(%s,'2026-10-31')",(A,)),mA.commit(),
  raises(lambda:mA.execute("select public.post_journal_entry(%s,%s::jsonb)",(A,je('old-1','2026-10-15',[(aA['cash'],1,0),(aA['sales'],0,1)]))),'ORVEX_PERIOD_CLOSED'),mA.rollback(),
  raises(lambda:mA.execute("select public.set_period_lock(%s,'2026-09-30')",(A,)),'ORVEX_PERIOD_CLOSED'),mA.rollback(),
  post(mA,A,je('new-1','2026-11-02',[(aA['cash'],1,0),(aA['sales'],0,1)]))=='posted' or (_ for _ in ()).throw(AssertionError('open period'))))
check('عزل المحلات: المحل B لا يقرأ بيانات A',lambda:[ (c:=mB.execute(f"select count(*) from {t}").fetchone()[0]) for t in ('acct_entries','acct_lines','acct_accounts')] and all(mB.execute(f"select count(*) from {t} where shop_id=%s",(A,)).fetchone()[0]==0 for t in ('acct_entries','acct_lines','acct_accounts','acct_periods')) or (_ for _ in ()).throw(AssertionError('leak')))
check('عزل المحلات: B لا يرحّل إلى A ولا يعكس قيود A',lambda:(
  raises(lambda:mB.execute("select public.post_journal_entry(%s,%s::jsonb)",(A,je('x1','2026-11-02',[(aA['cash'],1,0),(aA['sales'],0,1)]))),'ORVEX_FORBIDDEN'),mB.rollback(),
  raises(lambda:mB.execute("select public.reverse_journal_entry(%s,'new-1','r','2026-11-03','u')",(A,)),'ORVEX_FORBIDDEN'),mB.rollback()))
check('عزل المحلات: استخدام حساب محل آخر في قيد مرفوض',lambda:(raises(lambda:mB.execute("select public.post_journal_entry(%s,%s::jsonb)",(B,je('x2','2026-11-02',[(aA['cash'],1,0),(aB['sales'],0,1)]))),'ORVEX_BAD_ACCOUNT'),mB.rollback()))
check('دور staff أو جهاز غير مفعّل لا يرحّل',lambda:(
  raises(lambda:sess('staff',A).execute("select public.post_journal_entry(%s,%s::jsonb)",(A,je('s1','2026-11-02',[(aA['cash'],1,0),(aA['sales'],0,1)]))),'ORVEX_FORBIDDEN'),
  raises(lambda:sess('manager',A,'off').execute("select public.post_journal_entry(%s,%s::jsonb)",(A,je('s2','2026-11-02',[(aA['cash'],1,0),(aA['sales'],0,1)]))),'ORVEX_FORBIDDEN')))

mA.rollback()
def lines1():
    mA.execute("select public.post_journal_entry(%s,%s::jsonb)",(A,'{"id":"e0","entry_date":"2026-11-02","lines":[]}'));mA.commit()
check('قيد بلا أسطر يُرفض',lambda:(raises(lines1,'ORVEX_BAD_ENTRY'),mA.rollback()))
def badacct():
    mA.execute("select public.post_journal_entry(%s,%s::jsonb)",(A,'{"id":"e9","entry_date":"2026-11-02","lines":[{"account_id":"zz","debit":1,"credit":0},{"account_id":"yy","debit":0,"credit":1}]}'));mA.commit()
check('معرّف حساب غير صالح -> ORVEX_BAD_ENTRY',lambda:(raises(badacct,'ORVEX_BAD_ENTRY'),mA.rollback()))
def tbal():
    rows=mA.execute("select code,debit,credit,balance from public.trial_balance(%s,null,null)",(A,)).fetchall();mA.commit()
    assert sum(r[1] for r in rows)==sum(r[2] for r in rows),'tb غير متوازن'
    assert any(r[1]>0 for r in rows),'tb فارغ'
check('trial_balance متوازن',tbal)
check('trial_balance لمحل آخر مرفوض',lambda:(raises(lambda:mB.execute("select * from public.trial_balance(%s,null,null)",(A,)),'ORVEX_FORBIDDEN'),mB.rollback()))
def addacc():
    i=mA.execute("select public.add_account(%s,'6001','حساب اختبار','expense')",(A,)).fetchone()[0];mA.commit();assert i
    raises(lambda:mA.execute("select public.add_account(%s,'6001','مكرر','expense')",(A,)),'23505') if False else None
check('add_account',addacc)
fo=sess('founder',None)
check('المؤسس يرحّل لأي محل',lambda:post(fo,B,je('f1','2026-11-02',[(aB['cash'],1,0),(aB['sales'],0,1)]))=='posted' or (_ for _ in ()).throw(AssertionError('founder')))
check('حذف حساب فيه قيود مرحّلة ممنوع (لا يمسح الأسطر بالتتابع)',lambda:raises(lambda:adm.execute("delete from acct_accounts where id=%s",(aA['cash'],)),'ORVEX_JOURNAL_IMMUTABLE'))
check('حذف المحل (cascade) يعمل رغم منع حذف القيود',lambda:(adm.execute("delete from shops where id=%s",(B,)),adm.execute("select count(*) from acct_entries where shop_id=%s",(B,)).fetchone()[0]==0 or (_ for _ in ()).throw(AssertionError('left'))))
check('التراجع (rollback script) يرفض الحذف عند وجود قيود، وينجح مع force',lambda:(
  raises(lambda:adm.execute(down),'قيود مرحّلة'),
  adm.execute("set orvex.force_rollback=on"),adm.execute(down),
  adm.execute("select to_regclass('public.acct_entries')").fetchone()[0] is None or (_ for _ in ()).throw(AssertionError('still'))))
ok=sum(1 for r in res if r[1])
for n,p,m in res: print(('PASS ' if p else 'FAIL ')+n+('  <- '+m if m else ''))
print(f'\n{ok}/{len(res)} passed');srv.cleanup();sys.exit(0 if ok==len(res) else 1)
