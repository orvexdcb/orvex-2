const test=require('node:test'),assert=require('node:assert/strict');
const {mkInv3,mkLedger,shop}=require('./helpers');
const r2=n=>Math.round(n*100)/100;
function mk(opt){const db=shop();db.transfers=[];db.warehouses=[{id:'w2',name:'فرع 2',active:true}];
  db.products=[{id:'a',name:'أ',stock:20,cost:10,wh:{}},{id:'b',name:'ب',stock:5,cost:40,wh:{}}];
  return{db,I:mkInv3(db,opt)}}
const total=db=>db.products.reduce((s,p)=>s+p.stock,0);

/* ===== 5) تحويل بين مستودعين ===== */
test('5) تحويل كامل: مسودة ← إرسال ← استلام؛ المجموع محفوظ والكميات تنتقل بين المخزنين',()=>{
  const {db,I}=mk(),pa=db.products[0];
  const t=I.trCreate(I.MAIN,'w2',[{pid:'a',qty:8}]).ok;assert.equal(t.status,'draft');assert.equal(pa.stock,20);
  assert.ok(I.trSend(t.id).ok);assert.equal(t.status,'sent');assert.equal(I.whQty(pa,I.MAIN),12);assert.equal(pa.stock,12);/* في الطريق: لا يُحسب في أي مخزن */
  const r=I.trReceive(t.id);assert.ok(r.ok,JSON.stringify(r));
  assert.equal(I.whQty(pa,I.MAIN),12);assert.equal(I.whQty(pa,'w2'),8);assert.equal(pa.stock,20)});
test('5) التحويل لا ينشئ قيودًا محاسبية ولا يغيّر ميزان المراجعة (لا ربح/خسارة وهمية)',()=>{
  const {db,I}=mk();db.purchases.push({id:'p1',no:'P1',date:'2026-11-01',total:200,paid:200,method:'cash'});
  const before=JSON.stringify(mkLedger(db).tb('',''));
  const t=I.trCreate(I.MAIN,'w2',[{pid:'a',qty:8},{pid:'b',qty:2}]).ok;I.trSend(t.id);I.trReceive(t.id);
  assert.equal(JSON.stringify(mkLedger(db).tb('','')),before)});
test('5) التحويل يرفض: نفس المخزن، كمية أكبر من المتاح، مخزن معطّل، وبلا صلاحية',()=>{
  const {db,I}=mk();assert.ok(I.trCreate(I.MAIN,I.MAIN,[{pid:'a',qty:1}]).err);
  const t=I.trCreate(I.MAIN,'w2',[{pid:'a',qty:99}]).ok;assert.match(I.trSend(t.id).err,/الكمية غير كافية/);assert.equal(db.products[0].stock,20);
  db.warehouses[0].active=false;assert.ok(I.trCreate(I.MAIN,'w2',[{pid:'a',qty:1}]).err);
  const {I:J}=mk({can:false});assert.match(J.trCreate(J.MAIN,'w2',[{pid:'a',qty:1}]).err,/صلاحية/)});
test('5) إعادة الإرسال/الاستلام لا تكرر الحركة (idempotent بحالة المستند)',()=>{
  const {db,I}=mk(),pa=db.products[0],t=I.trCreate(I.MAIN,'w2',[{pid:'a',qty:5}]).ok;
  I.trSend(t.id);assert.ok(I.trSend(t.id).err);assert.equal(pa.stock,15);
  I.trReceive(t.id);assert.ok(I.trReceive(t.id).err);assert.equal(I.whQty(pa,'w2'),5);assert.equal(pa.stock,20)});
test('5) إلغاء تحويل مرسل يعيد الكمية للمرسل؛ ولا يُلغى بعد الاستلام',()=>{
  const {db,I}=mk(),pa=db.products[0],t=I.trCreate(I.MAIN,'w2',[{pid:'a',qty:5}]).ok;I.trSend(t.id);
  assert.ok(I.trCancel(t.id,'خطأ').ok);assert.equal(pa.stock,20);assert.equal(I.whQty(pa,I.MAIN),20);
  const t2=I.trCreate(I.MAIN,'w2',[{pid:'a',qty:5}]).ok;I.trSend(t2.id);I.trReceive(t2.id);assert.ok(I.trCancel(t2.id,'x').err)});
test('5) استلام جزئي مع تالف: يُسجَّل النقص والتالف والمجموع ينقص بقدرهما فقط',()=>{
  const {db,I}=mk(),pa=db.products[0],t=I.trCreate(I.MAIN,'w2',[{pid:'a',qty:10}]).ok;I.trSend(t.id);
  assert.ok(I.trReceive(t.id,{a:{recv:6,dmg:3}}).err===undefined);
  assert.equal(t.lines[0].short,1);assert.equal(t.lines[0].dmg,3);assert.equal(I.whQty(pa,'w2'),6);assert.equal(pa.stock,16);
  const t2=I.trCreate(I.MAIN,'w2',[{pid:'b',qty:2}]).ok;I.trSend(t2.id);assert.match(I.trReceive(t2.id,{b:{recv:2,dmg:1}}).err,/أكبر من المرسل/)});
test('5) نقص/تالف الاستلام يُسجَّل كخسارة مخزون (4×10=40) بقيد متوازن، والتحويل السليم بلا أي قيد',()=>{
  const {db,I}=mk();db.purchases.push({id:'p1',no:'P1',date:'2026-11-01',total:200,paid:200,method:'cash'});
  const inv=()=>mkLedger(db).tb('','').find(r=>r.code==='1140').balance,before=inv();
  const ok=I.trCreate(I.MAIN,'w2',[{pid:'b',qty:1}]).ok;I.trSend(ok.id);I.trReceive(ok.id);assert.equal(inv(),before);/* سليم */
  const t=I.trCreate(I.MAIN,'w2',[{pid:'a',qty:10}]).ok;I.trSend(t.id);I.trReceive(t.id,{a:{recv:6,dmg:3}});
  const L=mkLedger(db),rows=L.tb('','');assert.equal(inv(),before-40);
  assert.equal(rows.find(r=>r.code==='5500').balance,40);assert.equal(r2(rows.reduce((a,x)=>a+x.debit,0)),r2(rows.reduce((a,x)=>a+x.credit,0)));
  /* idempotent: إعادة بناء الدفتر لا تكرر القيد */
  assert.equal(mkLedger(db).entries().list.filter(e=>e.src==='transfer').length,1)});
test('5) تحويلات قديمة مستلمة بلا تكلفة مسجلة لا تُنتج قيودًا بأثر رجعي',()=>{
  const {db}=mk();db.transfers.push({id:'old',no:'TR-old',status:'received',date:'2026-10-01',recvAt:'2026-10-02T10:00:00Z',lines:[{pid:'a',qty:5,recv:3,short:2,dmg:0}]});
  assert.equal(mkLedger(db).entries().list.filter(e=>e.src==='transfer').length,0)});

/* ===== 6) الجرد والتسوية ===== */
test('6) جرد: عجز وزيادة يُطبَّقان بالفرق، ويُنتج قيدًا متوازنًا (عجز مصروف، زيادة تعويض)',()=>{
  const {db,I}=mk();db.settings.adjLimit=1e9;
  const s=I.skStart(I.MAIN).ok;I.skCount(s.id,'a',17);I.skCount(s.id,'b',7);
  const r=I.skSubmit(s.id,'جرد دوري','');assert.equal(r.state,'approved');
  assert.equal(db.products[0].stock,17);assert.equal(db.products[1].stock,7);
  assert.equal(JSON.stringify(s.lines.map(l=>l.applied)),JSON.stringify([-3,2]));
  const L=mkLedger(db),rows=L.tb('','');assert.equal(r2(rows.reduce((a,x)=>a+x.debit,0)),r2(rows.reduce((a,x)=>a+x.credit,0)));
  /* عجز 3×10=30 مصروف، زيادة 2×40=80 تخفض المصروف: صافي حساب 5500 = -50 (دائن) والمخزون +50 */
  assert.equal(rows.find(x=>x.code==='5500').balance,-50);assert.equal(rows.find(x=>x.code==='1140').balance,50)});
test('6) الفرق يُطبَّق كفرق لا كرقم مطلق: مبيعات أثناء العدّ لا تُلغى',()=>{
  const {db,I}=mk();db.settings.adjLimit=1e9;const s=I.skStart(I.MAIN).ok;I.skCount(s.id,'a',18);/* النظام 20 → العجز 2 */
  db.products[0].stock=15;/* بيع 5 أثناء العدّ */ I.skSubmit(s.id,'جرد دوري','');assert.equal(db.products[0].stock,13)});
test('6) الاعتماد: موظف فوق حد التسوية ينتظر المدير، والمدير يعتمد؛ الرفض لا يغيّر المخزون',()=>{
  const {db,I}=mk({admin:false});db.settings.adjLimit=10;
  const s=I.skStart(I.MAIN).ok;I.skCount(s.id,'a',10);const r=I.skSubmit(s.id,'تالف','');assert.equal(r.state,'pending');assert.equal(db.products[0].stock,20);
  assert.match(I.skApprove(s.id).err,/للمدير/);
  const A=mkInv3(db,{admin:true});assert.ok(A.skApprove(s.id).ok);assert.equal(db.products[0].stock,10);
  const s2=A.skStart(A.MAIN).ok;A.skCount(s2.id,'b',1);const E=mkInv3(db,{admin:false});db.settings.adjLimit=1;E.skSubmit(s2.id,'تالف','');
  assert.ok(A.skReject(s2.id,'غير مقبول').ok);assert.equal(db.products[1].stock,5)});
test('6) جلسة بلا فروق تُغلق دون قيد، وجلسة ثانية لنفس المخزن مرفوضة أثناء فتح الأولى، وكمية سالبة مرفوضة',()=>{
  const {db,I}=mk(),s=I.skStart(I.MAIN).ok;assert.ok(I.skStart(I.MAIN).err);I.skCount(s.id,'a',20);assert.ok(I.skCount(s.id,'a',-1).err);
  assert.equal(I.skSubmit(s.id,'جرد دوري','').state,'closed');assert.equal(mkLedger(db).entries().list.filter(e=>e.src==='stocktake').length,0)});
test('6) جرد مخزن فرعي لا يمس مخزنًا آخر (عزل الكميات بين المستودعات)',()=>{
  const {db,I}=mk();db.settings.adjLimit=1e9;db.products[0].wh={w2:6};/* الرئيسي 14 */
  const s=I.skStart('w2').ok;I.skCount(s.id,'a',4);I.skSubmit(s.id,'جرد دوري','');
  assert.equal(I.whQty(db.products[0],'w2'),4);assert.equal(I.whQty(db.products[0],I.MAIN),14);assert.equal(db.products[0].stock,18)});
