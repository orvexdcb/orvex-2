/* اختبار دخاني للواجهة داخل jsdom (يُتخطى تلقائيًا إن لم تكن jsdom مثبتة: npm i --no-save jsdom) */
const test=require('node:test'),assert=require('node:assert/strict');
let JSDOM;try{({JSDOM}=require('jsdom'))}catch(e){}
const {read}=require('./helpers');
test('واجهة مرتجع الشراء: تظهر الأزرار، تُفتح النافذة، يُسجَّل المرتجع، ويُمنع الحذف بعد وجود مرتجع',{skip:!JSDOM&&'jsdom غير مثبتة'},()=>{
  const dom=new JSDOM('<body><div id="modal"><div class="sh-body"></div></div></body>',{runScripts:'outside-only'});const w=dom.window;
  const toasts=[];let n=0,saved=0;
  w.eval(`
    var KEY='k';var db={settings:{},products:[{id:'a',name:'أ',stock:10,cost:12}],suppliers:[{id:'s1',balance:100}],preturns:[],
      purchases:[{id:'p1',no:'PUR-1',date:'2026-11-01',sid:'s1',total:100,lines:[{pid:'a',name:'أ',qty:10,net:100,lc:0}]}]};
    var state={pinv:{navIdx:0}};var uid=function(){return 'u'+(++window.__n)};window.__n=0;var today=function(){return '2026-11-05'};
    var can=function(){return true};var curUser=function(){return{name:'t'}};var esc=function(s){return String(s)};var jsq=esc;var money=function(v){return String(v)};var fdate=esc;
    var toast=function(m){window.__toasts.push(m)};window.__toasts=[];var save=function(){window.__saved=(window.__saved||0)+1};var render=function(){};
    var modal=function(t,h){document.querySelector('#modal .sh-body').innerHTML=h};
    var showPurchase=function(id){document.querySelector('#modal .sh-body').innerHTML='<div>فاتورة</div>'};
    var pinvDeleted=0;var pinvDelete=function(){pinvDeleted++};var pinvRevert=function(){};
  `);
  w.eval(read('preturns.js'));
  w.eval("showPurchase('p1')");
  let html=w.document.querySelector('#modal .sh-body').innerHTML;assert.ok(html.includes('مرتجع شراء'),'زر المرتجع غير ظاهر');
  w.eval("prOpen('p1')");assert.ok(w.document.getElementById('pr_q0'),'حقل الكمية غير موجود');
  w.document.getElementById('pr_q0').value='4';w.document.getElementById('pr_m').value='balance';
  w.eval("prSave('p1')");
  assert.equal(w.eval('db.preturns.length'),1);assert.equal(w.eval('db.products[0].stock'),6);assert.equal(w.eval('db.suppliers[0].balance'),60);
  assert.ok(w.eval('window.__saved')>=1);
  assert.ok(w.document.querySelector('#modal .sh-body').innerHTML.includes('مرتجعات هذه الفاتورة'),'قائمة المرتجعات غير ظاهرة');
  w.eval('pinvDelete()');assert.equal(w.eval('pinvDeleted'),0,'تم حذف فاتورة عليها مرتجع');
  assert.ok(w.eval('window.__toasts').some(t=>/مرتجعات شراء/.test(t)));
  assert.throws(()=>w.eval('pinvRevert(db.purchases[0])'),/ORVEX_PO_HAS_RETURNS/);
  /* ضغط مزدوج/تكرار: السجل الثاني يرفض لتجاوز المتاح فقط، ولا يتكرر الأثر */
  w.eval("prOpen('p1')");w.document.getElementById('pr_q0').value='7';w.eval("prSave('p1')");
  assert.equal(w.eval('db.preturns.length'),1);assert.equal(w.eval('db.products[0].stock'),6)});
