const test=require('node:test'),assert=require('node:assert/strict');
const {acct,mkLedger,shop}=require('./helpers');
const A=acct();
const sum=(rows,k)=>Math.round(rows.reduce((s,r)=>s+r[k],0)*100)/100;
const sumLines=l=>({d:Math.round(l.reduce((s,x)=>s+x.debit,0)*100)/100,c:Math.round(l.reduce((s,x)=>s+x.credit,0)*100)/100});

/* ---- قيود المستندات (accounting.js) ---- */
test('1) شراء: يزيد المخزون ويثبت التزام المورد (متوازن)',()=>{
  const l=A.purchaseLines({total:1000,paid:400,method:'cash'});
  const by=k=>l.filter(x=>x.key===k).reduce((s,x)=>s+x.debit-x.credit,0);
  assert.equal(by('inventory'),1000);assert.equal(by('cash'),-400);assert.equal(by('ap'),-600);
  const t=sumLines(l);assert.equal(t.d,t.c)});
test('2) بيع: إيراد + ضريبة + تكلفة بضاعة مباعة، ويخفض المخزون (متوازن)',()=>{
  const l=A.saleLines({total:115,tax:15,paid:115,method:'cash',cost:60});
  const by=k=>l.filter(x=>x.key===k).reduce((s,x)=>s+x.debit-x.credit,0);
  assert.equal(by('sales'),-100);assert.equal(by('vat_out'),-15);assert.equal(by('cogs'),60);assert.equal(by('inventory'),-60);assert.equal(by('cash'),115);
  const t=sumLines(l);assert.equal(t.d,t.c)});
test('بيع آجل جزئي: الباقي ذمم عملاء',()=>{
  const l=A.saleLines({total:200,tax:0,paid:50,method:'cash',cost:0});
  assert.equal(l.find(x=>x.key==='ar').debit,150);const t=sumLines(l);assert.equal(t.d,t.c)});
test('4) مرتجع بيع يعكس الإيراد والتكلفة؛ مرتجع للرصيد يخفض الذمم',()=>{
  const l=A.returnLines({total:115,net:100,method:'balance',cost:60});
  const by=k=>l.filter(x=>x.key===k).reduce((s,x)=>s+x.debit-x.credit,0);
  assert.equal(by('sales_returns'),100);assert.equal(by('vat_out'),15);assert.equal(by('ar'),-115);assert.equal(by('inventory'),60);assert.equal(by('cogs'),-60);
  const t=sumLines(l);assert.equal(t.d,t.c)});
test('كل قيد مستند متوازن لقيم كسرية متعددة (فحص عشوائي ثابت البذرة)',()=>{
  let s=12345;const rnd=()=>(s=(s*1103515245+12345)&0x7fffffff)/0x7fffffff;
  for(let i=0;i<2000;i++){
    const total=Math.round(rnd()*100000)/100,tax=Math.round(total*0.15*100)/100,paid=Math.round(rnd()*total*100)/100,cost=Math.round(rnd()*total*100)/100;
    for(const l of[A.saleLines({total,tax,paid,method:i%2?'cash':'card',cost}),A.purchaseLines({total,paid,method:'cash'}),A.returnLines({total,net:total-tax,method:i%2?'balance':'cash',cost})]){
      const t=sumLines(l);assert.ok(Math.abs(t.d-t.c)<0.005,JSON.stringify({total,tax,paid,cost,t}))}}});
test('expected(): مستند سليم يُرحَّل بلا عناصر متخطّاة',()=>{
  const db=shop();db.sales.push({id:'s1',no:'1',date:'2026-11-01',total:100,paid:100,tax:0,cost:0,method:'cash'});
  const ok=A.expected(db,'2026-01-01');assert.equal(ok.entries.length,1);assert.equal(ok.skipped.length,0)});
test('expected(): الفواتير الملغاة لا تُرحَّل، وما قبل تاريخ البدء يُتجاهل',()=>{
  const db=shop();db.sales.push({id:'s1',no:'1',date:'2026-11-01',total:100,paid:100,method:'cash',void:true},{id:'s2',no:'2',date:'2025-01-01',total:50,paid:50,method:'cash'});
  assert.equal(A.expected(db,'2026-01-01').entries.length,0)});

/* ---- عدم التكرار وإعادة المحاولة (plan) ---- */
test('9) idempotency: بعد الترحيل لا تُنتج الخطة أي إجراء، وإعادة التشغيل/المزامنة لا تكرر',()=>{
  const db=shop();db.sales.push({id:'s1',no:'1',date:'2026-11-01',total:100,paid:100,method:'cash',cost:40});db.purchases.push({id:'p1',no:'P1',date:'2026-11-01',total:500,paid:0,method:'cash'});
  const st={posted:{}};let p=A.plan(db,st,'2026-01-01','2026-11-10');assert.equal(p.actions.length,2);
  p.actions.forEach(a=>{st.posted[a.key]={v:a.v,hash:a.hash,active:true}});
  for(let i=0;i<5;i++)assert.equal(A.plan(db,st,'2026-01-01','2026-11-10').actions.length,0)});
test('معرّفات القيود حتمية: نفس المستند = نفس المعرّف على أي جهاز',()=>{
  const db=shop();db.sales.push({id:'s1',no:'1',date:'2026-11-01',total:100,paid:100,method:'cash'});
  const a=A.plan(db,{posted:{}},'2026-01-01','x').actions[0].entry.id,b=A.plan(JSON.parse(JSON.stringify(db)),{posted:{}},'2026-01-01','x').actions[0].entry.id;
  assert.equal(a,b);assert.equal(a,'sale-s1-v1')});
test('تعديل مستند مرحَّل: عكس النسخة القديمة ثم ترحيل جديدة (لا حذف للقيد المرحَّل)',()=>{
  const db=shop();db.sales.push({id:'s1',no:'1',date:'2026-11-01',total:100,paid:100,method:'cash'});
  const st={posted:{}};A.plan(db,st,'2026-01-01','x').actions.forEach(a=>{st.posted[a.key]={v:a.v,hash:a.hash,active:true}});
  db.sales[0].total=120;db.sales[0].paid=120;
  const p=A.plan(db,st,'2026-01-01','x');assert.deepEqual(p.actions.map(a=>a.type),['reverse','post']);assert.equal(p.actions[1].v,2)});
test('حذف مستند مرحَّل: عكس لا حذف',()=>{
  const db=shop();db.sales.push({id:'s1',no:'1',date:'2026-11-01',total:100,paid:100,method:'cash'});
  const st={posted:{}};A.plan(db,st,'2026-01-01','x').actions.forEach(a=>{st.posted[a.key]={v:a.v,hash:a.hash,active:true}});
  db.sales=[];const p=A.plan(db,st,'2026-01-01','x');assert.deepEqual(p.actions.map(a=>[a.type,a.deactivate]),[['reverse',true]])});

/* ---- الدفتر (ledger.js الحقيقي) ---- */
const jeIds=L=>L.accounts().reduce((m,a)=>(m[a.code]=a.id,m),{});
test('3) ميزان المراجعة: مجموع المدين = مجموع الدائن بعد شراء وبيع ومرتجع ومصروف ودفعات وقيد يدوي',()=>{
  const db=shop();db.purchases.push({id:'p1',no:'P1',date:'2026-11-01',total:1000,paid:300,method:'cash'});
  db.sales.push({id:'s1',no:'1',date:'2026-11-02',total:230,tax:30,paid:230,method:'cash',cost:120});
  db.returns.push({id:'r1',no:'R1',date:'2026-11-03',total:115,net:100,method:'cash',cost:60});
  db.expenses.push({id:'e1',date:'2026-11-03',amount:50,cat:'إيجار'});
  db.payments.push({id:'y1',date:'2026-11-04',amount:100,type:'s'});
  const L=mkLedger(db),ids=jeIds(L);
  const r=L.jeCreate('2026-11-05','افتتاحي',[{a:ids['1110'],d:500,c:0},{a:ids['3100'],d:0,c:500}]);assert.ok(r.ok,JSON.stringify(r));
  const rows=L.tb('','');assert.equal(sum(rows,'debit'),sum(rows,'credit'));
  const inv=rows.find(x=>x.code==='1140');assert.equal(inv.balance,1000-120+60)});
test('الأرباح والخسائر: صافي = إيراد − مردودات − تكلفة − مصروف',()=>{
  const db=shop();db.sales.push({id:'s1',no:'1',date:'2026-11-02',total:200,tax:0,paid:200,method:'cash',cost:80});
  db.expenses.push({id:'e1',date:'2026-11-03',amount:30,cat:'x'});
  const L=mkLedger(db);const is=L.incomeStatement(L.tb('',''));assert.equal(is.revenue,200);assert.equal(is.net,200-80-30)});
test('الميزانية العمومية: الأصول = الالتزامات + حقوق الملكية (+ صافي الربح)',()=>{
  const db=shop();db.purchases.push({id:'p1',no:'P1',date:'2026-11-01',total:1000,paid:0,method:'cash'});
  db.sales.push({id:'s1',no:'1',date:'2026-11-02',total:300,tax:0,paid:300,method:'cash',cost:100});
  const L=mkLedger(db),ids=jeIds(L);L.jeCreate('2026-10-31','رأس مال',[{a:ids['1110'],d:700,c:0},{a:ids['3100'],d:0,c:700}]);
  const bs=L.balanceSheet(L.tb('',''));const tot=o=>Object.values(o).filter(v=>typeof v==='number');
  const keys=Object.keys(bs);assert.ok(keys.length>0);
  /* الأصول: صندوق 700+300=1000، مخزون 1000−100=900 → 1900. الالتزامات 1000 + رأس مال 700 + ربح 200 = 1900 */
  const rows=L.tb('','');const bal=t=>rows.filter(r=>r.type===t).reduce((s,r)=>s+r.balance,0);
  assert.equal(bal('asset'),1900);assert.equal(-bal('liability')-bal('equity')-bal('revenue')-bal('expense'),1900)});
test('قيد يدوي: يرفض غير المتوازن وسطرًا مدينًا ودائنًا معًا ومبلغًا سالبًا وحسابًا غير موجود',()=>{
  const L=mkLedger(shop()),ids=jeIds(L),cash=ids['1110'],cap=ids['3100'];
  assert.match(L.jeCreate('2026-11-05','x',[{a:cash,d:100,c:0},{a:cap,d:0,c:99}]).err,/غير متوازن/);
  assert.ok(L.jeCreate('2026-11-05','x',[{a:cash,d:100,c:100},{a:cap,d:0,c:0}]).err);
  assert.ok(L.jeCreate('2026-11-05','x',[{a:cash,d:-5,c:0},{a:cap,d:0,c:-5}]).err);
  assert.ok(L.jeCreate('2026-11-05','x',[{a:'nope',d:5,c:0},{a:cap,d:0,c:5}]).err);
  assert.ok(L.jeCreate('2026-11-05','x',[{a:cash,d:5,c:0}]).err)});
test('إقفال الفترات: يمنع القيد في فترة مقفلة',()=>{
  const db=shop();db.settings.lockDate='2026-10-31';const L=mkLedger(db),ids=jeIds(L);
  assert.match(L.jeCreate('2026-10-31','x',[{a:ids['1110'],d:5,c:0},{a:ids['3100'],d:0,c:5}]).err||'',/مقفلة/);
  assert.ok(L.jeCreate('2026-11-01','x',[{a:ids['1110'],d:5,c:0},{a:ids['3100'],d:0,c:5}]).ok)});
test('القيد العكسي: يلغي الأثر، لا يُعكس مرتين، ولا يُعكس قيد عكسي، ويحتاج سببًا، والقيد الأصلي يبقى',()=>{
  const db=shop(),L=mkLedger(db),ids=jeIds(L);
  const j=L.jeCreate('2026-11-05','x',[{a:ids['1110'],d:80,c:0},{a:ids['3100'],d:0,c:80}]).ok;
  assert.ok(L.jeReverse(j.id,'').err);
  const r=L.jeReverse(j.id,'خطأ إدخال');assert.ok(r.ok,JSON.stringify(r));
  assert.equal(db.journals.length,2);assert.ok(db.journals.find(x=>x.id===j.id));
  assert.ok(L.jeReverse(j.id,'مرة ثانية').err);assert.ok(L.jeReverse(r.ok.id,'عكس العكسي').err);
  const rows=L.tb('','');assert.ok(rows.every(r=>r.balance===0)&&sum(rows,'debit')===160)});
test('القيود اليدوية للموظف غير المدير: العكس للمدير فقط',()=>{
  const db=shop(),adm=mkLedger(db),ids=jeIds(adm);
  const j=adm.jeCreate('2026-11-05','x',[{a:ids['1110'],d:80,c:0},{a:ids['3100'],d:0,c:80}]).ok;
  const emp=mkLedger(db,{admin:false});assert.match(emp.jeReverse(j.id,'سبب').err,/للمدير/)});
test('الجرد: تسوية معتمدة تنشئ قيد عجز/زيادة متوازنًا وغير المعتمدة لا تؤثر',()=>{
  const db=shop();db.stocktakes.push({id:'k1',no:'K1',status:'approved',date:'2026-11-06',lines:[{applied:-3,cost:10},{applied:2,cost:10}]},{id:'k2',no:'K2',status:'draft',date:'2026-11-06',lines:[{applied:-100,cost:10}]});
  const L=mkLedger(db);const e=L.entries().list.filter(x=>x.src==='stocktake');assert.equal(e.length,1);
  const rows=L.tb('','');assert.equal(sum(rows,'debit'),sum(rows,'credit'));
  assert.equal(rows.find(r=>r.code==='5500').balance,10);assert.equal(rows.find(r=>r.code==='1140').balance,-10)});
test('10) عزل المحلات: دفتر كل محل يعتمد على بياناته فقط',()=>{
  const a=shop(),b=shop();a.sales.push({id:'s1',no:'1',date:'2026-11-02',total:500,tax:0,paid:500,method:'cash',cost:0});
  const La=mkLedger(a),Lb=mkLedger(b);
  assert.equal(La.tb('','').find(r=>r.code==='4100').credit,500);assert.equal(Lb.tb('','').length,0);
  assert.equal(Lb.entries().list.length,0)});
