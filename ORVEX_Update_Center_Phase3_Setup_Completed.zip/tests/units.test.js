const test=require('node:test'),assert=require('node:assert/strict'),vm=require('vm');
const {mkInv2,read}=require('./helpers');
const mk=()=>{const db={settings:{},products:[
  {id:'a',name:'مياه',sku:'111',price:2,cost:1,stock:100,codes:[{code:'222',unit:'كرتون',f:12,price:20},{code:'333',unit:'علبة',f:6}]},
  {id:'b',name:'صابون',sku:'999',price:5,cost:3,stock:10}]};return{db,ctx:mkInv2(db)}};
test('7) باركودات متعددة لمنتج واحد: SKU والكرتون والعلبة تصل لنفس المنتج بمعاملات مختلفة',()=>{
  const {ctx}=mk();for(const [c,f] of [['111',0],['222',12],['333',6]]){const p=ctx.orvexFindByCode(c);assert.equal(p.id,'a');assert.equal(ctx.__scanQty,f)}
  assert.equal(ctx.orvexFindByCode('000'),null);assert.equal(ctx.orvexFindByCode('999').id,'b')});
test('7) بيع بوحدة الكرتون: السطر بالكمية الأساسية (12) وسعر الكرتون يُحوَّل لسعر القطعة فيبقى الإجمالي صحيحًا',()=>{
  const {ctx}=mk();ctx.doEntry('222');const l=ctx.state.cart[0];
  assert.equal(l.qty,12);assert.equal(l.price*l.qty,20);assert.equal(l.unit,'كرتون');assert.equal(l.cost*l.qty,12)});
test('7) بيع بوحدة بلا سعر خاص: يبقى سعر القطعة × المعامل، وبيع القطعة = 1',()=>{
  const {ctx}=mk();ctx.doEntry('333');assert.equal(ctx.state.cart[0].qty,6);assert.equal(ctx.state.cart[0].price*6,12);
  ctx.doEntry('111');assert.equal(ctx.state.cart[1].qty,1)});
test('7) باركود غير معروف يمر للمعالج الأصلي (بحث بالاسم)',()=>{const {ctx}=mk();ctx.doEntry('صاب');assert.equal(ctx.__fallback,'صاب')});
/* parseCodes الحقيقية (غير مُصدَّرة): تُستخرج من المصدر كما فعلنا مع FEFO */
function parser(db){const src=read('inventory2.js'),pick=(from,to)=>{const i=src.indexOf(from),j=src.indexOf(to,i+from.length);if(i<0||j<0)throw new Error('تعذّر استخراج: '+from);return src.slice(i,j)};
  const code=pick('const lc=','const ISO')+pick('function codesOf','function hit')+pick('const lines=t=>','\n/* ',).replace(/\n\/\*[\s\S]*$/,'');
  const ctx={db,num:v=>{const x=parseFloat(v);return isFinite(x)?x:0},r2:v=>Math.round((parseFloat(v)||0)*100)/100};vm.createContext(ctx);
  vm.runInContext(code+';this.parseCodes=parseCodes',ctx);return ctx.parseCodes}
test('7) التحقق عند الحفظ: باركود مكرر داخل المنتج أو مستخدم لمنتج آخر، ومعامل غير صالح، ومعامل لا يقسم السعر',()=>{
  const {db}=mk(),pc=parser(db);
  assert.ok(pc('444 | علبة | 6','a','111').err===undefined);
  assert.match(pc('444\n444','a','111').err,/مكرر/);assert.match(pc('999','a','111').err,/مستخدم للمادة/);
  assert.match(pc('555 | x | 0','a','111').err,/معامل/);assert.match(pc('555 | x | 7 | 10','a','111').err,/القسمة/);
  assert.match(pc('111','a','111').err,/مكرر/)});
