const test=require('node:test'),assert=require('node:assert/strict'),fs=require('fs'),vm=require('vm'),path=require('path');
const root=path.join(__dirname,'..');
const read=f=>fs.readFileSync(path.join(root,f),'utf8');
function mkStorage(){const m=new Map();return{getItem:k=>m.has(k)?m.get(k):null,setItem:(k,v)=>m.set(k,String(v)),removeItem:k=>m.delete(k),_m:m}}
/* يحاكي إعادة تحميل الصفحة: سياق JS جديد بنفس sessionStorage (كما يفعل المتصفح داخل التبويب نفسه) */
function pageLoad(storage){const ctx={sessionStorage:storage,console};ctx.window=ctx;vm.createContext(ctx);vm.runInContext(read('session-store.js'),ctx);return ctx.orvexSession}

test('1) حفظ الجلسة قبل التحديث واستعادتها بعد إعادة التحميل (مؤسس ومحل)',()=>{
  for(const u of['founder1','shop_manager']){
    const st=mkStorage();let S=pageLoad(st);
    assert.ok(S.save({username:u,rt:'rt-1',uid:'uid-'+u}));
    S.markUpdate();
    S=pageLoad(st);                                   // إعادة التحميل
    const s=S.load();assert.equal(s.username,u);assert.equal(s.rt,'rt-1');assert.ok(S.isUpdate());
  }});
test('3) تحديثات متتالية متعددة لا تفقد الجلسة، ودوران الرمز يُحفظ',()=>{
  const st=mkStorage();let S=pageLoad(st);S.save({username:'a',rt:'r1',uid:'u'});
  for(let i=2;i<=6;i++){S.markUpdate();S=pageLoad(st);assert.equal(S.load().rt,'r'+(i-1));S.save({username:'a',rt:'r'+i,uid:'u'});S.endRestore()}
  assert.equal(pageLoad(st).load().rt,'r6')});
test('6) إعادة تحميل عادية للصفحة (بلا علامة تحديث) تستعيد الجلسة أيضًا',()=>{
  const st=mkStorage();let S=pageLoad(st);S.save({username:'a',rt:'r1',uid:'u'});S=pageLoad(st);assert.equal(S.isUpdate(),false);assert.equal(S.load().rt,'r1')});
test('7) تسجيل الخروج: يمسح الرمز ويمنع أي حفظ متأخر (عدم عودة الجلسة بعد الخروج)',()=>{
  const st=mkStorage();let S=pageLoad(st);S.save({username:'a',rt:'r1',uid:'u'});
  S.clear();S.suspend();
  assert.equal(S.save({username:'a',rt:'r2',uid:'u'}),false);   // تجديد متأخر للرمز بعد الخروج
  assert.equal(pageLoad(st).load(),null);
  S.resume();assert.ok(S.save({username:'a',rt:'r3',uid:'u'}))});
test('10) الجلسة المنتهية/المبطلة: لا حلقة، والتصنيف صحيح',()=>{
  const S=pageLoad(mkStorage());
  for(const c of[400,401,403,422])assert.equal(S.classify(c),'expired');
  for(const c of[0,429,500,502,503])assert.equal(S.classify(c),'transient')});
test('حارس الحلقات: 3 محاولات استعادة كحد أقصى خلال 60 ثانية، ويُصفّر عند النجاح',()=>{
  const st=mkStorage();const S=pageLoad(st);
  assert.ok(S.beginRestore());assert.ok(S.beginRestore());assert.ok(S.beginRestore());assert.equal(S.beginRestore(),false);
  S.endRestore();assert.ok(S.beginRestore())});
test('لا تُحفظ كلمة مرور: المحتوى المخزن اسم مستخدم + رمز + uid فقط',()=>{
  const st=mkStorage();const S=pageLoad(st);S.save({username:'a',rt:'r',uid:'u',password:'SECRET123',pw:'SECRET123'});
  const raw=st.getItem(S.KEY);assert.ok(!/SECRET123/.test(raw));assert.deepEqual(Object.keys(JSON.parse(raw)).sort(),['rt','t','uid','username'])});
test('sessionStorage غير متاح (وضع خاص/منع): لا استثناءات ولا انهيار',()=>{
  const bad={getItem(){throw new Error('x')},setItem(){throw new Error('x')},removeItem(){throw new Error('x')}};
  const S=pageLoad(bad);assert.equal(S.save({username:'a',rt:'r'}),false);assert.equal(S.load(),null);S.clear();assert.ok(S.beginRestore()===true||true)});

/* ---- فحوص بنيوية للشيفرة ---- */
test('تسجيل الخروج وتحديث البرنامج منفصلان: التحديث لا يمسح الجلسة ولا يستدعي logout أو signOut',()=>{
  const pwa=read('pwa.js'),srv=read('server.js');
  assert.ok(!/clear\(|clearTabSession|removeItem|localStorage\.clear|sessionStorage\.clear|logout|signOut|auth\/v1\/logout/.test(pwa));
  assert.ok(!/auth\/v1\/logout|signOut/.test(srv));
  assert.ok(/window\.__orvexPrepareUpdate=function\(\)\{saveTabSession\(\);/.test(srv))});
test('لا تخزين لكلمة المرور في localStorage/sessionStorage في أي ملف',()=>{
  for(const f of fs.readdirSync(root).filter(f=>f.endsWith('.js'))){
    const t=read(f);assert.ok(!/(localStorage|sessionStorage)\.setItem\([^)]*(a_pass|password|\bpw\b)/.test(t),f)}});
test('sbLogin: فشل الاستعادة لا يعرض رسالة "كلمة المرور غير صحيحة" ويمسح الجلسة المنتهية فقط',()=>{
  const s=read('server.js');
  assert.ok(s.includes("if(resume){if(ORVEX_SESS.classify(r.status)==='expired'){ORVEX_SESS.clear()"));
  assert.ok(s.includes("ORVEX_SESS.suspend()"));assert.ok(s.includes("ORVEX_SESS.beginRestore()"))});
test('Service Worker: كل ملفات CORE موجودة، وsession-store مضاف، وكل سكربتات index.html مخزنة للعمل دون إنترنت',()=>{
  const sw=read('sw.js'),core=[...sw.match(/CORE=\[(.*?)\];/s)[1].matchAll(/'([^']+)'/g)].map(m=>m[1]);
  for(const f of core)if(f!=='./')assert.ok(fs.existsSync(path.join(root,f)),'مفقود: '+f);
  const idx=read('index.html'),scripts=[...idx.matchAll(/<script src="([^"]+)"/g)].map(m=>m[1]);
  for(const s of scripts)assert.ok(core.includes(s),'غير مخزن: '+s);
  assert.ok(idx.indexOf('session-store.js')>0&&idx.indexOf('session-store.js')<idx.indexOf('server.js'));
  assert.match(sw,/VER='orvex-root-v52-release-center'/)});
test('Service Worker (محاكاة): التثبيت يخزن الملفات، التفعيل يحذف الكاشات القديمة فقط، رسالة SKIP_WAITING تعمل، الطلبات غير المتزامنة لا تُعترض',async()=>{
  const log={deleted:[],skip:0,added:null,fetched:[]},handlers={};
  const caches={open:async()=>({addAll:async f=>{log.added=f},put:async()=>{},match:async()=>undefined}),keys:async()=>['orvex-v48-session-restore','orvex-v49-session-keep','orvex-v50-reports','orvex-v51-acct-wire','orvex-root-v51-old','orvex-release-1.0.0','other'],delete:async k=>{log.deleted.push(k)},match:async()=>undefined};
  const self={addEventListener:(t,f)=>handlers[t]=f,skipWaiting:()=>{log.skip++},clients:{claim:async()=>{}}};
  const ctx={self,caches,location:{origin:'https://x.test'},URL,Request:class{constructor(r,o){this.url=r.url;this.cache=o&&o.cache}},fetch:async r=>{log.fetched.push(r);return{ok:true,clone(){return this}}},Promise};
  vm.createContext(ctx);vm.runInContext(read('sw.js'),ctx);
  let p;handlers.install({waitUntil:x=>p=x});await p;assert.ok(log.added.includes('session-store.js'));assert.equal(log.skip,1);
  handlers.activate({waitUntil:x=>p=x});await p;assert.deepEqual(log.deleted.sort(),['orvex-root-v51-old','orvex-v48-session-restore','orvex-v49-session-keep','orvex-v50-reports','orvex-v51-acct-wire'].sort());
  handlers.message({data:{type:'SKIP_WAITING'}});assert.equal(log.skip,2);
  let responded=false;handlers.fetch({request:{method:'GET',url:'https://abc.supabase.co/rest/v1/x',mode:'cors'},respondWith:()=>{responded=true}});assert.equal(responded,false);
  handlers.fetch({request:{method:'GET',url:'https://x.test/pos.js',mode:'no-cors'},respondWith:x=>{responded=true;p=x}});await p;assert.ok(responded);assert.equal(log.fetched.at(-1).cache,'no-cache')});
