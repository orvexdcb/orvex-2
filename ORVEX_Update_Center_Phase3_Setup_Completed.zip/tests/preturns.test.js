const test=require('node:test'),assert=require('node:assert/strict'),fs=require('fs'),path=require('path');
const {acct,mkLedger,shop,read}=require('./helpers');
const PR=require('../preturns.js'),C=require('../costing.js'),A=acct();
const r2=n=>Math.round(n*100)/100;
function base(){const db=shop();db.suppliers=[{id:'s1',name:'مورد',balance:600}];db.preturns=[];
  db.products=[{id:'a',name:'أ',stock:10,cost:12},{id:'b',name:'ب',stock:5,cost:20,trackBatch:true,batches:[{no:'L1',qty:3},{no:'L2',qty:2}]}];
  db.purchases=[{id:'p1',no:'PUR-1',date:'2026-11-01',sid:'s1',method:'credit',total:1000,paid:400,lines:[{pid:'a',name:'أ',qty:10,net:100,lc:20},{pid:'b',name:'ب',qty:5,net:100}]}];return db}
const env=(o={})=>({uid:(()=>{let n=0;return()=>'r'+(++n)})(),today:()=>'2026-11-05',no:'PR-1',by:'t',...o});
const ret=(db,items,method='cash',e)=>PR.create(db,{poId:'p1',items,method},e||env());

test('4) مرتجع شراء نقدي: يخفض المخزون بالتكلفة الأصلية شاملة تكاليف الوصول',()=>{
  const db=base(),r=ret(db,[{pid:'a',qty:4}]);assert.ok(r.ok,JSON.stringify(r));
  assert.equal(db.products[0].stock,6);assert.equal(r.ok.items[0].cost,12);assert.equal(r.ok.total,48);
  assert.equal(r.ok.apPart,0);assert.equal(r.ok.cashPart,48);assert.equal(db.suppliers[0].balance,600)});
test('مرتجع بخصم الذمة: يخفض رصيد المورد، والزائد على رصيده يُسترد نقدًا',()=>{
  const db=base();db.suppliers[0].balance=30;const r=ret(db,[{pid:'a',qty:4}],'balance');
  assert.equal(r.ok.apPart,30);assert.equal(r.ok.cashPart,18);assert.equal(db.suppliers[0].balance,0);assert.equal(r.ok.cashMethod,'cash')});
test('خصم الذمة بدون مورد مرفوض',()=>{const db=base();db.purchases[0].sid='';const before=JSON.stringify(db);assert.ok(ret(db,[{pid:'a',qty:1}],'balance').err);assert.equal(JSON.stringify(db),before)});
test('لا يتجاوز الكمية المشتراة، والمرتجعات المتتالية تتراكم',()=>{
  const db=base();assert.ok(ret(db,[{pid:'a',qty:6}]).ok);assert.ok(ret(db,[{pid:'a',qty:4}]).ok);
  const e=ret(db,[{pid:'a',qty:1}]);assert.match(e.err,/أكبر من المتاح للإرجاع/);assert.equal(db.products[0].stock,0)});
test('المخزون غير الكافي (بيع جزء منه) يمنع الإرجاع',()=>{const db=base();db.products[0].stock=2;assert.match(ret(db,[{pid:'a',qty:5}]).err,/المخزون غير كافٍ/);assert.equal(db.products[0].stock,2)});
test('منتج بتشغيلات: يلزم تحديد التشغيلة وتنخفض كميتها فقط',()=>{
  const db=base();assert.match(ret(db,[{pid:'b',qty:1}]).err,/حدد تشغيلة/);
  assert.match(ret(db,[{pid:'b',qty:3,lot:'L2'}]).err,/أقل من المرتجع/);
  assert.ok(ret(db,[{pid:'b',qty:2,lot:'L2'}]).ok);assert.equal(db.products[1].batches[1].qty,0);assert.equal(db.products[1].batches[0].qty,3);assert.equal(db.products[1].stock,3)});
test('ذرّية: فشل أي صنف لا يغيّر شيئًا في أي صنف آخر',()=>{
  const db=base(),before=JSON.stringify(db);assert.ok(ret(db,[{pid:'a',qty:2},{pid:'b',qty:1}]).err);assert.equal(JSON.stringify(db),before)});
test('مخازن متعددة: الصرف من المخزن المحدد عبر whMove والتحقق من رصيده',()=>{
  const db=base(),calls=[];const whQty=(p,w)=>w==='w2'?1:p.stock;
  assert.match(ret(db,[{pid:'a',qty:2,wh:'w2'}],'cash',env({whQty})).err,/غير كافٍ/);
  const r=ret(db,[{pid:'a',qty:1,wh:'w2'}],'cash',env({whQty,whMove:(p,w,d)=>{calls.push([p.id,w,d]);p.stock+=d}}));
  assert.ok(r.ok);assert.equal(JSON.stringify(calls),JSON.stringify([['a','w2',-1]]))});
test('hasReturns: يكشف فاتورة عليها مرتجعات لمنع تعديلها/حذفها',()=>{const db=base();assert.equal(PR.hasReturns(db,db.purchases[0]),false);ret(db,[{pid:'a',qty:1}]);assert.equal(PR.hasReturns(db,db.purchases[0]),true)});
test('طرق استرداد غير صالحة وكمية صفرية مرفوضة',()=>{const db=base();assert.ok(PR.create(db,{poId:'p1',items:[{pid:'a',qty:1}],method:'x'}).err);assert.ok(ret(db,[{pid:'a',qty:0}]).err);assert.ok(PR.create(db,{poId:'nope',items:[{pid:'a',qty:1}],method:'cash'}).err)});

/* ---- المحاسبة والدفتر ---- */
test('قيد مرتجع الشراء متوازن: مدين ذمة مورد/صندوق، دائن مخزون',()=>{
  const l=A.preturnLines({total:100,apPart:60,cashMethod:'cash'}),by=k=>l.filter(x=>x.key===k).reduce((s,x)=>s+x.debit-x.credit,0);
  assert.equal(by('ap'),60);assert.equal(by('cash'),40);assert.equal(by('inventory'),-100);
  const bank=A.preturnLines({total:100,apPart:0,cashMethod:'transfer'});assert.equal(bank.find(x=>x.key==='bank').debit,100)});
test('3) الدفتر الحقيقي: شراء ثم مرتجع → ميزان متوازن، المخزون = الشراء − المرتجع، وذمة المورد تنخفض',()=>{
  const db=base();ret(db,[{pid:'a',qty:4}],'balance');
  const L=mkLedger(db),rows=L.tb('','');
  assert.equal(r2(rows.reduce((s,r)=>s+r.debit,0)),r2(rows.reduce((s,r)=>s+r.credit,0)));
  assert.equal(rows.find(r=>r.code==='1140').balance,1000-48);
  assert.equal(rows.find(r=>r.code==='2110').balance,-(600-48));
  assert.ok(L.entries().list.some(e=>e.src==='preturn'))});
test('9) idempotency: بعد ترحيل المرتجع لا إجراءات جديدة، والمعرّف حتمي',()=>{
  const db=base();ret(db,[{pid:'a',qty:2}]);const st={posted:{}};
  const p=A.plan(db,st,'2026-01-01','x');assert.ok(p.actions.some(a=>a.entry&&a.entry.id==='preturn-r1-v1'));
  p.actions.forEach(a=>{st.posted[a.key]={v:a.v,hash:a.hash,active:true}});assert.equal(A.plan(db,st,'2026-01-01','x').actions.length,0)});
test('10) عزل المحلات: مرتجعات محل لا تظهر في دفتر محل آخر',()=>{
  const a=base(),b=shop();ret(a,[{pid:'a',qty:2}]);const Lb=mkLedger(b);assert.equal(Lb.entries().list.length,0);assert.equal(mkLedger(a).entries().list.filter(e=>e.src==='preturn').length,1)});
test('تكلفة FIFO: مرتجع الشراء يستهلك طبقة فاتورته الأصلية لا أقدم طبقة أخرى',()=>{
  const ev=[{type:'in',date:'2026-11-01',qty:5,unitCost:5,ref:'po:p0:0'},{type:'in',date:'2026-11-02',qty:5,unitCost:9,ref:'po:p1:0'},{type:'out',date:'2026-11-03',qty:2,fromRef:'po:p1:0',ref:'pr'},{type:'out',date:'2026-11-04',qty:5,ref:'s'}];
  const r=C.value(ev,'fifo');assert.equal(r.outs[0].cost,18);assert.equal(r.outs[1].cost,r2(5*5));assert.equal(r.remValue,r2(3*9))});
test('movements يلتقط مرتجع الشراء من db.preturns',()=>{const db=base();ret(db,[{pid:'a',qty:3}]);assert.ok(C.movements(db,'a').some(e=>e.isPReturn&&e.qty===3&&e.fromRef==='po:p1:0'))});

/* ---- ربط بنيوي ---- */
test('المجموعة مسجّلة للمزامنة: الافتراضي والمزامنة وتسمية المزامنة، والملف محمّل ومخزّن دون إنترنت',()=>{
  assert.ok(/preturns:\[\]/.test(read('core.js')));assert.ok(/'repRuns','preturns'\]/.test(read('server.js')));assert.ok(/preturns:'مرتجعات الشراء'/.test(read('syncq.js')));
  assert.ok(read('index.html').indexOf('preturns.js')>read('index.html').indexOf('inventory3.js'));assert.ok(/'preturns\.js'/.test(read('sw.js')))});
test('الواجهة تمنع حذف/تعديل فاتورة عليها مرتجعات (wrappers موجودة)',()=>{const s=read('preturns.js');assert.ok(/pinvDelete=function/.test(s)&&/pinvRevert=function/.test(s)&&/ORVEX_PO_HAS_RETURNS/.test(s))});
