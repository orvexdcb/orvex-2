const test=require('node:test'),assert=require('node:assert/strict'),vm=require('vm');
const {mkLedger,shop,read}=require('./helpers');
const r2=n=>Math.round(n*100)/100;
/* يحمّل accounting-ui.js الحقيقي مع DOM مبسّط ويعرض تبويبَي التدفقات وأعمار الديون من دفتر ledger.js الحقيقي */
function mkUI(db,opt){
  opt=opt||{};const L=mkLedger(db),el={innerHTML:'',insertAdjacentHTML(pos,h){this.innerHTML=pos==='afterbegin'?h+this.innerHTML:this.innerHTML+h}},msgs=[];
  const ctx={db,console,ORVEX_LED:L,__orvexAcct:{ok:()=>true,shop:()=>'x'},isAdmin:()=>opt.admin!==false,today:()=>'2026-11-10',money:v=>'$'+v,esc:s=>String(s),
    curUser:()=>({name:'t'}),modal(){},toast:m=>msgs.push(m),
    document:{getElementById:id=>id==='acBody'?el:null,querySelectorAll:()=>[]}};
  ctx.window=ctx;ctx.globalThis=ctx;vm.createContext(ctx);vm.runInContext(read('accounting-ui.js'),ctx,{filename:'accounting-ui.js'});
  return{ctx,el,msgs,L};
}
const mk=()=>{const db=shop();db.customers=[{id:'c1',name:'عميل 1',balance:0}];db.suppliers=[{id:'s1',name:'مورد',balance:0}];db.preturns=[];db.products=[];return db};

test('تبويب التدفقات النقدية يظهر في الواجهة بأرقام مطابقة للدفتر وبعلامة مطابقة',async()=>{
  const db=mk();db.sales.push({id:'v1',no:'I1',date:'2026-11-02',total:200,paid:200,method:'cash',cost:80});db.expenses.push({id:'e1',date:'2026-11-04',amount:30,cat:'إيجار',method:'cash'});
  const u=mkUI(db);u.ctx.acOpen('cf');await new Promise(r=>setTimeout(r,20));
  const cf=u.L.cashFlow('2026-11-01','2026-11-10');
  assert.equal(cf.net,170);assert.ok(cf.reconciled);
  assert.match(u.el.innerHTML,/الأنشطة التشغيلية/);assert.match(u.el.innerHTML,/\$170/);assert.match(u.el.innerHTML,/✓ الافتتاحي/);
  assert.match(u.el.innerHTML,/تصدير Excel/);assert.deepEqual(u.msgs,[])});
test('تبويب أعمار الديون: عملاء ثم موردون، والإجمالي يطابق الرصيد، وغير المفسَّر ظاهر',async()=>{
  const db=mk();db.sales.push({id:'s1',no:'I1',cid:'c1',date:'2026-07-01',total:100,paid:0,method:'credit'},{id:'s2',no:'I2',cid:'c1',date:'2026-11-05',total:30,paid:0,method:'credit'});
  db.customers[0].balance=130+500;   /* 500 رصيد افتتاحي بلا مستندات */
  db.purchases.push({id:'o1',no:'P1',sid:'s1',date:'2026-11-01',total:200,paid:50});db.suppliers[0].balance=150;
  const u=mkUI(db);u.ctx.acOpen('ag');await new Promise(r=>setTimeout(r,20));
  const a=u.L.aging('c','2026-11-10');
  assert.equal(a.docsTotal,130);assert.equal(a.unallocatedTotal,500);assert.equal(a.balanceTotal,630);
  assert.match(u.el.innerHTML,/\$630/);assert.match(u.el.innerHTML,/\$500/);assert.match(u.el.innerHTML,/غير مفسَّر/);assert.match(u.el.innerHTML,/عميل 1/);
  u.ctx.acAgType('s');await new Promise(r=>setTimeout(r,20));
  assert.match(u.el.innerHTML,/مورد/);assert.match(u.el.innerHTML,/\$150/);assert.doesNotMatch(u.el.innerHTML,/عميل 1/)});
test('أعمار الديون: لا ديون → رسالة فارغة، وغير المدير لا يفتح التبويبات',async()=>{
  const u=mkUI(mk());u.ctx.acOpen('ag');await new Promise(r=>setTimeout(r,20));assert.match(u.el.innerHTML,/لا ديون مستحقة/);
  const v=mkUI(mk(),{admin:false});v.ctx.acOpen('cf');assert.deepEqual(v.msgs,['للمدير فقط'])});
test('التبويبان للقراءة فقط: لا يغيّران أي بيانات في db (بعد تهيئة الدفتر الموجودة أصلًا)',async()=>{
  const db=mk();db.sales.push({id:'v1',no:'I1',date:'2026-11-02',total:200,paid:200,method:'cash',cost:80});db.customers[0].balance=10;
  const u=mkUI(db);u.L.tb('','2026-11-10');   /* ensure() الموجودة تضيف مصفوفات فارغة مرة واحدة */
  const before=JSON.stringify(db);for(const t of['cf','ag']){u.ctx.acOpen(t);await new Promise(r=>setTimeout(r,20))}
  assert.equal(JSON.stringify(db),before)});
