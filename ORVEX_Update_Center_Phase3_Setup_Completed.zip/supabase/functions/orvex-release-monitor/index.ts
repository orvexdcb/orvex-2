import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.57.0'

const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), {
  status, headers: { 'Content-Type': 'application/json' },
})
const decode = (value: string) => {
  const normalized = value.replace(/-/g, '+').replace(/_/g, '/')
  const raw = atob(normalized + '='.repeat((4 - normalized.length % 4) % 4))
  return Uint8Array.from(raw, c => c.charCodeAt(0))
}

Deno.serve(async (req) => {
  const secret = Deno.env.get('ORVEX_RELEASE_TICKET_SECRET') || ''
  if (secret.length < 32 || req.headers.get('x-orvex-monitor-secret') !== secret)
    return json({ error: 'unauthorized' }, 401)
  if (req.method === 'GET') return json({ enabled: true })
  if (req.method !== 'POST') return json({ error: 'method_not_allowed' }, 405)

  let body: Record<string, unknown>
  try { body = await req.json() } catch { return json({ error: 'invalid_json' }, 400) }
  if (body.action !== 'report_proxy_failure') return json({ error: 'unknown_action' }, 400)

  const ticket = String(body.ticket || '')
  const parts = ticket.split('.')
  if (parts.length !== 2 || ticket.length > 4096) return json({ error: 'invalid_ticket' }, 401)
  let payload: Record<string, unknown>
  try { payload = JSON.parse(new TextDecoder().decode(decode(parts[0]))) }
  catch { return json({ error: 'invalid_ticket_payload' }, 401) }

  try {
    const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(secret),
      { name: 'HMAC', hash: 'SHA-256' }, false, ['verify'])
    const valid = await crypto.subtle.verify('HMAC', key, decode(parts[1]), new TextEncoder().encode(parts[0]))
    if (!valid || !payload.releaseId || !payload.sub || !payload.tenantId ||
        !Number.isFinite(Number(payload.exp)) || Number(payload.exp) <= Math.floor(Date.now() / 1000))
      return json({ error: 'invalid_or_expired_ticket' }, 401)

    const url = Deno.env.get('SUPABASE_URL')!
    const service = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    const admin = createClient(url, service, { auth: { persistSession: false, autoRefreshToken: false } })
    const releaseId = String(payload.releaseId)
    const { data: release, error: releaseError } = await admin.from('orvex_releases')
      .select('id,status').eq('id', releaseId).maybeSingle()
    if (releaseError) throw releaseError

    const status = Number(body.upstream_status || 502)
    if (status < 500 || status > 599) return json({ error: 'failure_status_not_reportable' }, 400)
    if (!release || release.status !== 'published') return json({ ok: true, ignored: true })

    const path = String(body.path || '').slice(0, 240)
    const { error: eventError } = await admin.from('orvex_release_events').insert({
      release_id: releaseId, actor_id: String(payload.sub), event_type: 'proxy_asset_failure',
      details: { upstream_status: status, path, tenant_type: payload.tenantType, tenant_id: payload.tenantId },
    })
    if (eventError) throw eventError

    const cutoff = new Date(Date.now() - 5 * 60 * 1000).toISOString()
    const { data: failures, error: failuresError } = await admin.from('orvex_release_events')
      .select('actor_id').eq('release_id', releaseId).eq('event_type', 'proxy_asset_failure')
      .gte('created_at', cutoff).order('created_at', { ascending: false }).limit(500)
    if (failuresError) throw failuresError
    const affectedUsers = new Set((failures || []).map(x => x.actor_id).filter(Boolean))
    if (affectedUsers.size >= 3) {
      const reason = `Automatic quarantine: upstream 5xx failures observed for ${affectedUsers.size} users within 5 minutes`
      const { error: updateError } = await admin.from('orvex_releases').update({
        status: 'quarantined', quarantined_at: new Date().toISOString(), failure_reason: reason,
      }).eq('id', releaseId).eq('status', 'published')
      if (updateError) throw updateError
      const { error: quarantineEventError } = await admin.from('orvex_release_events').insert({
        release_id: releaseId, actor_id: null, event_type: 'automatic_quarantine',
        details: { reason, affected_users: affectedUsers.size, window_minutes: 5 },
      })
      if (quarantineEventError) throw quarantineEventError
      return json({ ok: true, quarantined: true, affected_users: affectedUsers.size })
    }
    return json({ ok: true, quarantined: false, affected_users: affectedUsers.size })
  } catch (error) {
    console.error('[orvex-release-monitor]', error)
    return json({ error: 'monitor_failed' }, 500)
  }
})
