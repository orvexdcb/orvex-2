import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.57.0'

const cors = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
}
const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), {
  status, headers: { ...cors, 'Content-Type': 'application/json' },
})
const semver = /^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(-[0-9A-Za-z.-]+)?(\+[0-9A-Za-z.-]+)?$/

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: cors })
  if (req.method !== 'POST') return json({ error: 'method_not_allowed' }, 405)

  const url = Deno.env.get('SUPABASE_URL')!
  const anon = Deno.env.get('SUPABASE_ANON_KEY')!
  const service = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
  const authHeader = req.headers.get('Authorization') || ''
  if (!authHeader.startsWith('Bearer ')) return json({ error: 'unauthorized' }, 401)

  const authClient = createClient(url, anon, { global: { headers: { Authorization: authHeader } } })
  const { data: authData, error: authError } = await authClient.auth.getUser()
  if (authError || !authData.user) return json({ error: 'unauthorized' }, 401)

  const admin = createClient(url, service, { auth: { persistSession: false, autoRefreshToken: false } })
  const { data: profile, error: profileError } = await admin
    .from('profiles').select('id,role,active,shop_id').eq('id', authData.user.id).maybeSingle()
  if (profileError) return json({ error: 'profile_check_failed' }, 500)
  if (!profile || profile.active === false) return json({ error: 'account_inactive' }, 403)

  let body: Record<string, unknown>
  try { body = await req.json() } catch { return json({ error: 'invalid_json' }, 400) }
  const action = String(body.action || '')
  const isFounder = profile.role === 'founder'
  if (!isFounder && !['manifest','issue_ticket'].includes(action)) return json({ error: 'founder_only' }, 403)
  const actor = authData.user.id
  const event = async (releaseId: string | null, eventType: string, details: unknown = {}) => {
    const { error } = await admin.from('orvex_release_events').insert({
      release_id: releaseId, actor_id: actor, event_type: eventType, details,
    })
    if (error) throw error
  }

  try {
    if (action === 'manifest') {
      // Tenant identity is derived exclusively from the authenticated profile.
      const tenantType = profile.role === 'founder' ? 'founder' : 'shop'
      const tenantId = tenantType === 'founder' ? authData.user.id : String(profile.shop_id || '')
      if (!tenantId) return json({ release: null, reason: 'tenant_not_linked' })
      const { data: releases, error: releasesError } = await admin.from('orvex_releases')
        .select('id,version,title,notes,artifact_url,artifact_sha256,published_at,orvex_release_targets(*)')
        .eq('status', 'published').order('published_at', { ascending: false }).limit(100)
      if (releasesError) throw releasesError
      for (const r of releases || []) {
        const targets = r.orvex_release_targets || []
        const excluded = targets.some((t: Record<string, unknown>) => t.excluded === true &&
          ((t.target_type === 'all') || (t.target_type === tenantType && String(t.target_id || '') === tenantId)))
        if (excluded) continue
        const included = targets.some((t: Record<string, unknown>) => t.excluded !== true &&
          (t.target_type === 'all' || (t.target_type === tenantType && String(t.target_id || '') === tenantId)))
        if (included) return json({ release: { id:r.id, version:r.version, title:r.title, notes:r.notes, deployment_url:r.artifact_url, sha256:r.artifact_sha256, published_at:r.published_at } })
      }
      return json({ release: null, reason: 'no_published_update' })
    }

    if (action === 'list_shops') {
      const { data, error } = await admin.from('shops').select('id,name').order('name').limit(500)
      if (error) throw error
      return json({ shops: data || [] })
    }

    if (action === 'issue_ticket') {
      const releaseId = String(body.release_id || '')
      if (!releaseId) return json({ error: 'release_id_required' }, 400)
      const secret = Deno.env.get('ORVEX_RELEASE_TICKET_SECRET') || ''
      if (secret.length < 32) return json({ error: 'release_ticket_secret_not_configured' }, 503)
      if (Deno.env.get('ORVEX_RELEASE_ROUTING_ENABLED') !== 'true')
        return json({ error: 'release_routing_not_enabled' }, 503)
      const tenantType = profile.role === 'founder' ? 'founder' : 'shop'
      const tenantId = tenantType === 'founder' ? authData.user.id : String(profile.shop_id || '')
      if (!tenantId) return json({ error: 'tenant_not_linked' }, 403)
      const { data: r, error: releaseError } = await admin.from('orvex_releases')
        .select('id,version,artifact_url,status').eq('id', releaseId).maybeSingle()
      if (releaseError) throw releaseError
      if (!r || r.status !== 'published' || !r.artifact_url) return json({ error: 'release_not_published' }, 404)
      const { data: targets, error: targetsError } = await admin.from('orvex_release_targets')
        .select('target_type,target_id,excluded').eq('release_id', releaseId)
      if (targetsError) throw targetsError
      const excluded = (targets || []).some(t => t.excluded === true &&
        (t.target_type === 'all' || (t.target_type === tenantType && String(t.target_id || '') === tenantId)))
      const included = (targets || []).some(t => t.excluded !== true &&
        (t.target_type === 'all' || (t.target_type === tenantType && String(t.target_id || '') === tenantId)))
      if (excluded || !included) return json({ error: 'release_not_assigned_to_tenant' }, 403)
      const payload = {
        sub: authData.user.id, tenantType, tenantId, releaseId,
        version: r.version, deploymentUrl: r.artifact_url,
        exp: Math.floor(Date.now() / 1000) + 600,
      }
      const encoded = btoa(String.fromCharCode(...new TextEncoder().encode(JSON.stringify(payload))))
        .replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/g, '')
      const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(secret),
        { name: 'HMAC', hash: 'SHA-256' }, false, ['sign'])
      const signature = new Uint8Array(await crypto.subtle.sign('HMAC', key, new TextEncoder().encode(encoded)))
      const sig = btoa(String.fromCharCode(...signature)).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/g, '')
      await event(releaseId, 'release_ticket_issued', { tenant_type: tenantType, tenant_id: tenantId, expires_at: new Date(payload.exp * 1000).toISOString() })
      return json({ ticket: `${encoded}.${sig}`, expires_at: new Date(payload.exp * 1000).toISOString(), version: r.version })
    }

    if (action === 'list') {
      const [{ data, error }, { data: events, error: eventsError }] = await Promise.all([
        admin.from('orvex_releases').select('*,orvex_release_targets(*)')
          .order('created_at', { ascending: false }).limit(100),
        admin.from('orvex_release_events').select('id,release_id,actor_id,event_type,created_at,details')
          .order('created_at', { ascending: false }).limit(100),
      ])
      if (error) throw error
      if (eventsError) throw eventsError
      const distributionEnabled = Deno.env.get('ORVEX_RELEASE_ROUTING_ENABLED') === 'true' &&
        (Deno.env.get('ORVEX_RELEASE_TICKET_SECRET') || '').length >= 32
      return json({ releases: data || [], events: events || [], distribution_enabled: distributionEnabled })
    }

    if (action === 'create') {
      const version = String(body.version || '').trim()
      const title = String(body.title || '').trim()
      const notes = String(body.notes || '').trim()
      if (!semver.test(version) || !title) return json({ error: 'invalid_release_fields' }, 400)
      const { data, error } = await admin.from('orvex_releases').insert({
        version, title, notes, status: 'draft', created_by: actor,
      }).select().single()
      if (error) throw error
      await event(data.id, 'release_created', { version })
      return json({ release: data })
    }

    const releaseId = String(body.release_id || '')
    if (!releaseId) return json({ error: 'release_id_required' }, 400)
    const { data: release, error: readError } = await admin.from('orvex_releases')
      .select('*').eq('id', releaseId).maybeSingle()
    if (readError) throw readError
    if (!release) return json({ error: 'release_not_found' }, 404)

    if (action === 'set_targets') {
      if (['published','quarantined','rolled_back'].includes(release.status))
        return json({ error: 'targets_locked_for_terminal_release' }, 409)
      const targets = Array.isArray(body.targets) ? body.targets : []
      if (!targets.length) return json({ error: 'at_least_one_target_required' }, 400)
      for (const t of targets as Record<string, unknown>[]) {
        if (!['all','shop','founder'].includes(String(t.target_type)))
          return json({ error: 'invalid_target_type' }, 400)
        if (t.target_type !== 'all' && !String(t.target_id || '').trim())
          return json({ error: 'target_id_required' }, 400)
      }
      const { error: delError } = await admin.from('orvex_release_targets').delete().eq('release_id', releaseId)
      if (delError) throw delError
      const rows = (targets as Record<string, unknown>[]).map(t => ({
        release_id: releaseId, target_type: t.target_type,
        target_id: t.target_type === 'all' ? null : (t.target_type === 'founder' && String(t.target_id) === 'self' ? actor : String(t.target_id)), excluded: !!t.excluded,
      }))
      const { error } = await admin.from('orvex_release_targets').insert(rows)
      if (error) throw error
      await event(releaseId, 'targets_changed', { targets: rows })
      return json({ ok: true })
    }

    if (action === 'set_artifact') {
      if (!['draft','testing'].includes(release.status))
        return json({ error: 'artifact_locked' }, 409)
      const artifactUrl = String(body.artifact_url || '').trim().replace(/\/$/, '')
      const sha256 = String(body.artifact_sha256 || '').trim().toLowerCase()
      let parsedUrl: URL
      try { parsedUrl = new URL(artifactUrl) } catch { return json({ error: 'invalid_artifact_url' }, 400) }
      if (parsedUrl.protocol !== 'https:' || !parsedUrl.hostname.endsWith('.vercel.app') || parsedUrl.pathname !== '/' || parsedUrl.search || parsedUrl.hash || !/^[a-f0-9]{64}$/.test(sha256))
        return json({ error: 'invalid_artifact' }, 400)
      // Verify the immutable Vercel deployment package and its signed-by-content manifest.
      const bypassSecret = Deno.env.get('VERCEL_AUTOMATION_BYPASS_SECRET') || ''
      const artifactHeaders = bypassSecret ? { 'x-vercel-protection-bypass': bypassSecret } : {}
      const [zipResponse, manifestResponse] = await Promise.all([
        fetch(`${artifactUrl}/orvex-release.zip`, { headers: artifactHeaders }),
        fetch(`${artifactUrl}/orvex-release.json`, { headers: artifactHeaders }),
      ])
      if (!zipResponse.ok || !manifestResponse.ok) return json({ error: 'artifact_files_unavailable' }, 422)
      const maxArtifactBytes = 50 * 1024 * 1024
      const declaredLength = Number(zipResponse.headers.get('content-length') || 0)
      if (declaredLength > maxArtifactBytes) return json({ error: 'artifact_too_large' }, 413)
      if (!zipResponse.body) return json({ error: 'artifact_body_missing' }, 422)
      const reader = zipResponse.body.getReader()
      const chunks: Uint8Array[] = []
      let totalBytes = 0
      while (true) {
        const { done, value } = await reader.read()
        if (done) break
        totalBytes += value.byteLength
        if (totalBytes > maxArtifactBytes) { await reader.cancel(); return json({ error: 'artifact_too_large' }, 413) }
        chunks.push(value)
      }
      const zipBytes = new Uint8Array(totalBytes)
      let offset = 0
      for (const chunk of chunks) { zipBytes.set(chunk, offset); offset += chunk.byteLength }
      const actualHash = Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256', zipBytes)))
        .map(v => v.toString(16).padStart(2, '0')).join('')
      let artifactManifest: Record<string, unknown>
      try { artifactManifest = await manifestResponse.json() } catch { return json({ error: 'invalid_artifact_manifest' }, 422) }
      if (actualHash !== sha256 || artifactManifest.sha256 !== sha256 || artifactManifest.version !== release.version || artifactManifest.product !== 'ORVEX' || artifactManifest.artifact !== 'orvex-release.zip')
        return json({ error: 'artifact_integrity_or_version_mismatch' }, 422)
      const { error } = await admin.from('orvex_releases').update({
        artifact_url: artifactUrl, artifact_sha256: sha256,
      }).eq('id', releaseId)
      if (error) throw error
      await event(releaseId, 'artifact_registered', { artifact_url: artifactUrl, artifact_sha256: sha256, verified: true })
      return json({ ok: true })
    }

    if (action === 'start_testing') {
      if (release.status !== 'draft') return json({ error: 'invalid_state_transition' }, 409)
      const { error } = await admin.from('orvex_releases').update({ status: 'testing' }).eq('id', releaseId)
      if (error) throw error
      await event(releaseId, 'testing_started')
      return json({ ok: true })
    }

    if (action === 'approve') {
      if (release.status !== 'testing') return json({ error: 'invalid_state_transition' }, 409)
      if (!release.artifact_url || !release.artifact_sha256)
        return json({ error: 'immutable_artifact_and_sha256_required' }, 409)
      const { error } = await admin.from('orvex_releases').update({
        status: 'approved', approved_by: actor, approved_at: new Date().toISOString(),
      }).eq('id', releaseId)
      if (error) throw error
      await event(releaseId, 'release_approved')
      return json({ ok: true })
    }

    if (action === 'publish') {
      if (Deno.env.get('ORVEX_RELEASE_ROUTING_ENABLED') !== 'true' ||
          (Deno.env.get('ORVEX_RELEASE_TICKET_SECRET') || '').length < 32)
        return json({ error: 'distribution_not_configured', message: 'فعّل أولاً مسار التوزيع الآمن ومفتاح التذاكر في Vercel وSupabase.' }, 409)
      if (release.status !== 'approved' || !release.artifact_url || !release.artifact_sha256)
        return json({ error: 'release_not_ready' }, 409)
      const { data: targets, error: targetsError } = await admin.from('orvex_release_targets')
        .select('id').eq('release_id', releaseId)
      if (targetsError) throw targetsError
      if (!targets || !targets.length) return json({ error: 'release_targets_required' }, 409)
      const { error } = await admin.from('orvex_releases').update({
        status: 'published', published_by: actor, published_at: new Date().toISOString(),
      }).eq('id', releaseId)
      if (error) throw error
      await event(releaseId, 'release_published', { target_count: targets.length, artifact_url: release.artifact_url })
      return json({ ok: true, status: 'published', message: 'تم نشر الإصدار للجهات المحددة فقط.' })
    }

    if (action === 'pause' || action === 'quarantine') {
      if (['rolled_back'].includes(release.status)) return json({ error: 'release_terminal' }, 409)
      const next = action === 'pause' ? 'paused' : 'quarantined'
      const patch: Record<string, unknown> = { status: next, failure_reason: String(body.reason || '') }
      if (action === 'pause') patch.paused_at = new Date().toISOString()
      else patch.quarantined_at = new Date().toISOString()
      const { error } = await admin.from('orvex_releases').update(patch).eq('id', releaseId)
      if (error) throw error
      await event(releaseId, next, { reason: patch.failure_reason })
      return json({ ok: true, status: next })
    }

    if (action === 'rollback') {
      if (release.status !== 'published') return json({ error: 'release_not_published' }, 409)
      // Removing this release from the published set makes manifest() fall back
      // to the previous published release matching each tenant's targeting rules.
      const { error } = await admin.from('orvex_releases').update({
        status: 'rolled_back', failure_reason: String(body.reason || 'Founder requested rollback'),
      }).eq('id', releaseId)
      if (error) throw error
      await event(releaseId, 'release_rolled_back', { mode: 'tenant_manifest_fallback', reason: String(body.reason || '') })
      return json({ ok: true, mode: 'tenant_manifest_fallback',
        message: 'تم إيقاف توزيع هذا الإصدار؛ سيعود كل محل إلى أحدث إصدار سابق منشور ومطابق لاستهدافه.' })
    }

    return json({ error: 'unknown_action' }, 400)
  } catch (e) {
    console.error('[orvex-release-center]', e)
    return json({ error: 'internal_error' }, 500)
  }
})
