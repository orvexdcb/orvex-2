-- ORVEX — النواة المحاسبية المرحَّلة (مقترح للمراجعة — لم يُطبَّق)
-- إضافي فقط: لا يمس أي جدول أو بيانات قائمة. يطابق واجهة accounting.js الموجودة
-- (post_journal_entry / reverse_journal_entry / seed_default_accounts / system_key).
-- الحماية على مستوى قاعدة البيانات: القيد المرحَّل لا يُعدَّل ولا يُحذف، ولا يُقبل قيد غير متوازن،
-- والمعرّف الفريد (shop_id,id) يمنع التكرار عند إعادة المحاولة، والفترة المقفلة ترفض الترحيل.

create table public.acct_accounts (
  id          uuid primary key default gen_random_uuid(),
  shop_id     uuid not null references public.shops(id) on delete cascade,
  code        text not null check (code ~ '^[0-9]{3,8}$'),
  name        text not null check (length(btrim(name)) > 0),
  type        text not null check (type in ('asset','liability','equity','revenue','expense')),
  system_key  text,
  parent_id   uuid references public.acct_accounts(id),
  is_active   boolean not null default true,
  created_at  timestamptz not null default now(),
  unique (shop_id, code)
);
create unique index acct_accounts_system_key_uq on public.acct_accounts (shop_id, system_key) where system_key is not null;
create index acct_accounts_parent_ix on public.acct_accounts (parent_id);

create table public.acct_entries (
  shop_id      uuid not null references public.shops(id) on delete cascade,
  id           text not null check (length(id) between 1 and 200),
  entry_date   date not null,
  memo         text not null default '',
  source       text not null default 'manual',
  source_ref   text,
  reversed_of  text,
  created_by   text not null default '',
  created_at   timestamptz not null default now(),
  primary key (shop_id, id),
  foreign key (shop_id, reversed_of) references public.acct_entries (shop_id, id)
);
create unique index acct_entries_one_reversal_uq on public.acct_entries (shop_id, reversed_of) where reversed_of is not null;
create index acct_entries_date_ix on public.acct_entries (shop_id, entry_date);
create index acct_entries_source_ix on public.acct_entries (shop_id, source, source_ref);

create table public.acct_lines (
  shop_id     uuid not null,
  entry_id    text not null,
  line_no     int  not null,
  account_id  uuid not null references public.acct_accounts(id) on delete cascade,  -- cascade لازم لحذف المحل؛ حذف حساب فيه قيود يُمنع بـ trigger
  debit       numeric(18,2) not null default 0 check (debit  >= 0),
  credit      numeric(18,2) not null default 0 check (credit >= 0),
  primary key (shop_id, entry_id, line_no),
  foreign key (shop_id, entry_id) references public.acct_entries (shop_id, id) on delete cascade,
  check ((debit > 0 and credit = 0) or (credit > 0 and debit = 0))
);
create index acct_lines_account_ix on public.acct_lines (account_id);

create table public.acct_periods (
  shop_id       uuid primary key references public.shops(id) on delete cascade,
  locked_until  date,
  updated_at    timestamptz not null default now()
);

-- ===== عدم التعديل/الحذف للقيود المرحَّلة =====
create function private.acct_immutable() returns trigger
language plpgsql set search_path = '' as $$
begin
  if tg_op = 'UPDATE' then
    raise exception 'ORVEX_JOURNAL_IMMUTABLE: القيد المرحّل لا يُعدَّل، استخدم قيدًا عكسيًا';
  end if;
  -- يُسمح بالحذف فقط عند حذف المحل نفسه (cascade)؛ وإلا لا حذف للقيود المرحلة
  if exists (select 1 from public.shops s where s.id = old.shop_id) then
    raise exception 'ORVEX_JOURNAL_IMMUTABLE: القيد المرحّل لا يُحذف، استخدم قيدًا عكسيًا';
  end if;
  return old;
end $$;
create trigger acct_entries_immutable before update or delete on public.acct_entries for each row execute function private.acct_immutable();
create trigger acct_lines_immutable   before update or delete on public.acct_lines   for each row execute function private.acct_immutable();

-- ===== التوازن: مجموع المدين = مجموع الدائن وسطران على الأقل (يُفحص عند اكتمال العملية) =====
create function private.acct_check_balanced() returns trigger
language plpgsql set search_path = '' as $$
declare d numeric; c numeric; n int;
begin
  select coalesce(sum(debit),0), coalesce(sum(credit),0), count(*) into d, c, n
    from public.acct_lines where shop_id = new.shop_id and entry_id = new.entry_id;
  if n < 2 or d <> c then
    raise exception 'ORVEX_UNBALANCED: القيد % غير متوازن (مدين %, دائن %, أسطر %)', new.entry_id, d, c, n;
  end if;
  return null;
end $$;
create constraint trigger acct_lines_balanced after insert on public.acct_lines
  deferrable initially deferred for each row execute function private.acct_check_balanced();

-- ===== الصلاحيات و RLS (نفس نمط الجداول القائمة: المؤسس أو المحل نفسه المرخَّص + ربط الجهاز) =====
alter table public.acct_accounts enable row level security;
alter table public.acct_entries  enable row level security;
alter table public.acct_lines    enable row level security;
alter table public.acct_periods  enable row level security;

revoke all on public.acct_accounts, public.acct_entries, public.acct_lines, public.acct_periods from anon, public, authenticated;
grant select on public.acct_accounts, public.acct_entries, public.acct_lines, public.acct_periods to authenticated;  -- القراءة فقط؛ الكتابة عبر الدوال أدناه

do $$ declare t text; begin
  foreach t in array array['acct_accounts','acct_entries','acct_lines','acct_periods'] loop
    execute format($f$create policy %I on public.%I for select to authenticated using (
      (select private.my_role()) = 'founder' or (shop_id = (select private.my_shop()) and (select private.my_shop_licensed())))$f$, t||'_read', t);
    execute format($f$create policy device_bound on public.%I as restrictive for all to authenticated using ((select private.my_device_ok())) with check ((select private.my_device_ok()))$f$, t);
    execute format($f$create policy mall_guard on public.%I as restrictive for all to authenticated using ((select not private.mall_is_manager())) with check ((select not private.mall_is_manager()))$f$, t);
  end loop;
end $$;

-- ===== فحص الصلاحية المشترك للدوال =====
create function private.acct_assert_access(p_shop uuid) returns void
language plpgsql stable set search_path = '' as $$
begin
  if not (private.my_device_ok()) then raise exception 'ORVEX_FORBIDDEN: الجهاز غير مفعّل'; end if;
  if private.my_role() = 'founder' then return; end if;
  if private.my_role() is distinct from 'manager' or p_shop is distinct from private.my_shop() or not private.my_shop_licensed() then
    raise exception 'ORVEX_FORBIDDEN: لا صلاحية على هذا المحل';
  end if;
end $$;

-- ===== الحسابات الافتراضية (تطابق BASE في ledger.js) =====
create function public.seed_default_accounts(p_shop uuid) returns int
language plpgsql security definer set search_path = '' as $$
declare n int;
begin
  perform private.acct_assert_access(p_shop);
  insert into public.acct_accounts (shop_id, code, name, type, system_key) values
   (p_shop,'1110','الصندوق','asset','cash'),(p_shop,'1120','البنك / الدفع الإلكتروني (عام)','asset','bank'),
   (p_shop,'1130','ذمم العملاء','asset','ar'),(p_shop,'1140','المخزون','asset','inventory'),
   (p_shop,'1150','ضريبة مدخلات','asset','vat_in'),(p_shop,'1210','الأصول الثابتة','asset','fixed_assets'),
   (p_shop,'1219','مجمع الإهلاك','asset','acc_dep'),(p_shop,'2110','ذمم الموردين','liability','ap'),
   (p_shop,'2120','ضريبة مخرجات','liability','vat_out'),(p_shop,'2130','رواتب مستحقة','liability','payroll_payable'),
   (p_shop,'3100','رأس المال','equity','capital'),(p_shop,'3200','الأرباح المحتجزة','equity','retained'),
   (p_shop,'4100','إيرادات المبيعات','revenue','sales'),(p_shop,'4150','مردودات المبيعات','revenue','sales_returns'),
   (p_shop,'4190','خصومات المبيعات','revenue','sales_discount'),(p_shop,'5100','تكلفة البضاعة المباعة','expense','cogs'),
   (p_shop,'5200','المصروفات التشغيلية','expense','opex'),(p_shop,'5300','الرواتب والأجور','expense','payroll'),
   (p_shop,'5400','الإهلاك','expense','depreciation'),(p_shop,'5450','خسائر (أرباح) استبعاد الأصول','expense','asset_disposal'),
   (p_shop,'5500','فروق ومخزون تالف','expense','inventory_adjust'),(p_shop,'5600','عجز وزيادة الصندوق','expense','cash_diff')
  on conflict do nothing;
  get diagnostics n = row_count; return n;
end $$;

-- ===== ترحيل قيد: idempotent بمعرّف القيد =====
create function public.post_journal_entry(p_shop uuid, p_entry jsonb) returns text
language plpgsql security definer set search_path = '' as $$
declare eid text := p_entry->>'id'; edate date; lock date; ln jsonb; i int := 0; bad int;
begin
  perform private.acct_assert_access(p_shop);
  begin edate := (p_entry->>'entry_date')::date; exception when others then raise exception 'ORVEX_BAD_ENTRY: تاريخ غير صالح'; end;
  if eid is null or edate is null or jsonb_typeof(p_entry->'lines') is distinct from 'array' or jsonb_array_length(p_entry->'lines') < 2 then raise exception 'ORVEX_BAD_ENTRY: بيانات القيد ناقصة أو أقل من سطرين'; end if;
  perform pg_advisory_xact_lock(hashtextextended(p_shop::text || ':je:' || eid, 0));
  if exists (select 1 from public.acct_entries where shop_id = p_shop and id = eid) then return 'duplicate'; end if;
  select locked_until into lock from public.acct_periods where shop_id = p_shop;
  if lock is not null and edate <= lock then raise exception 'ORVEX_PERIOD_CLOSED: الفترة مقفلة حتى %', lock; end if;
  begin
    select count(*) into bad from jsonb_array_elements(p_entry->'lines') l
      where not exists (select 1 from public.acct_accounts a where a.id = (l->>'account_id')::uuid and a.shop_id = p_shop and a.is_active);
  exception when invalid_text_representation then raise exception 'ORVEX_BAD_ENTRY: معرّف حساب غير صالح'; end;
  if bad > 0 then raise exception 'ORVEX_BAD_ACCOUNT: حساب غير صالح أو من محل آخر'; end if;
  insert into public.acct_entries (shop_id, id, entry_date, memo, source, source_ref, created_by)
  values (p_shop, eid, edate, coalesce(p_entry->>'memo',''), coalesce(p_entry->>'source','manual'), p_entry->>'source_ref', coalesce(p_entry->>'created_by',''));
  for ln in select * from jsonb_array_elements(p_entry->'lines') loop
    i := i + 1;
    insert into public.acct_lines (shop_id, entry_id, line_no, account_id, debit, credit)
    values (p_shop, eid, i, (ln->>'account_id')::uuid, coalesce((ln->>'debit')::numeric,0), coalesce((ln->>'credit')::numeric,0));
  end loop;
  return 'posted';
end $$;

-- ===== عكس قيد: قيد جديد بأسطر معكوسة، الأصل يبقى =====
create function public.reverse_journal_entry(p_shop uuid, p_id text, p_new_id text, p_date date, p_by text default '') returns text
language plpgsql security definer set search_path = '' as $$
declare lock date; src public.acct_entries;
begin
  perform private.acct_assert_access(p_shop);
  perform pg_advisory_xact_lock(hashtextextended(p_shop::text || ':je:' || p_id, 0));
  select * into src from public.acct_entries where shop_id = p_shop and id = p_id;
  if not found then return 'not_found'; end if;
  if src.reversed_of is not null then raise exception 'ORVEX_BAD_ENTRY: لا يُعكس قيد عكسي'; end if;
  if exists (select 1 from public.acct_entries where shop_id = p_shop and reversed_of = p_id) then return 'already_reversed'; end if;
  if exists (select 1 from public.acct_entries where shop_id = p_shop and id = p_new_id) then return 'duplicate'; end if;
  select locked_until into lock from public.acct_periods where shop_id = p_shop;
  if lock is not null and p_date <= lock then raise exception 'ORVEX_PERIOD_CLOSED: الفترة مقفلة حتى %', lock; end if;
  insert into public.acct_entries (shop_id, id, entry_date, memo, source, source_ref, reversed_of, created_by)
  values (p_shop, p_new_id, p_date, 'عكس: ' || src.memo, 'reversal', src.source_ref, p_id, coalesce(p_by,''));
  insert into public.acct_lines (shop_id, entry_id, line_no, account_id, debit, credit)
  select p_shop, p_new_id, line_no, account_id, credit, debit from public.acct_lines where shop_id = p_shop and entry_id = p_id;
  return 'reversed';
end $$;

-- ===== إقفال الفترة (تقديم فقط: لا يُرجَع التاريخ للخلف) =====
create function public.set_period_lock(p_shop uuid, p_until date) returns date
language plpgsql security definer set search_path = '' as $$
declare cur date;
begin
  perform private.acct_assert_access(p_shop);
  select locked_until into cur from public.acct_periods where shop_id = p_shop;
  if cur is not null and p_until < cur then raise exception 'ORVEX_PERIOD_CLOSED: لا يمكن إعادة فتح فترة مقفلة'; end if;
  insert into public.acct_periods (shop_id, locked_until) values (p_shop, p_until)
  on conflict (shop_id) do update set locked_until = excluded.locked_until, updated_at = now();
  return p_until;
end $$;


-- ===== ميزان المراجعة لفترة (تستدعيه شاشات الميزان والدخل والميزانية) =====
create function public.trial_balance(p_shop uuid, p_from date, p_to date)
returns table (id uuid, code text, name text, type text, debit numeric, credit numeric, balance numeric)
language plpgsql stable security definer set search_path = '' as $$
begin
  perform private.acct_assert_access(p_shop);
  return query
  select a.id, a.code, a.name, a.type,
         coalesce(sum(l.debit),0)::numeric, coalesce(sum(l.credit),0)::numeric,
         (coalesce(sum(l.debit),0) - coalesce(sum(l.credit),0))::numeric
    from public.acct_accounts a
    left join public.acct_lines l on l.account_id = a.id and l.shop_id = a.shop_id
    left join public.acct_entries e on e.shop_id = l.shop_id and e.id = l.entry_id
         and (p_from is null or e.entry_date >= p_from) and (p_to is null or e.entry_date <= p_to)
   where a.shop_id = p_shop
   group by a.id, a.code, a.name, a.type
   order by a.code;
end $$;

-- ===== إضافة حساب (المدير/المؤسس): الكتابة المباشرة على الجدول ممنوعة =====
create function public.add_account(p_shop uuid, p_code text, p_name text, p_type text) returns uuid
language plpgsql security definer set search_path = '' as $$
declare nid uuid;
begin
  perform private.acct_assert_access(p_shop);
  insert into public.acct_accounts (shop_id, code, name, type) values (p_shop, btrim(p_code), btrim(p_name), p_type) returning id into nid;
  return nid;
end $$;

revoke all on function public.seed_default_accounts(uuid), public.post_journal_entry(uuid, jsonb),
  public.reverse_journal_entry(uuid, text, text, date, text), public.set_period_lock(uuid, date),
  public.trial_balance(uuid, date, date), public.add_account(uuid, text, text, text) from public, anon;
grant execute on function public.seed_default_accounts(uuid), public.post_journal_entry(uuid, jsonb),
  public.reverse_journal_entry(uuid, text, text, date, text), public.set_period_lock(uuid, date),
  public.trial_balance(uuid, date, date), public.add_account(uuid, text, text, text) to authenticated;
