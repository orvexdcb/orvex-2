-- تراجع عن 20261110120000_acct_core.sql — يحذف الجداول الجديدة فقط (لا يمس أي جدول قائم).
-- تحذير: يحذف القيود المرحَّلة إن وُجدت. يرفض التنفيذ إن كان فيها بيانات إلا بعد تعيين orvex.force_rollback=on.
do $$ begin
  if exists (select 1 from public.acct_entries limit 1) and coalesce(current_setting('orvex.force_rollback', true),'off') <> 'on' then
    raise exception 'يوجد قيود مرحّلة. صدّرها أولًا ثم: set orvex.force_rollback=on';
  end if;
end $$;
drop function if exists public.add_account(uuid, text, text, text);
drop function if exists public.trial_balance(uuid, date, date);
drop function if exists public.set_period_lock(uuid, date);
drop function if exists public.reverse_journal_entry(uuid, text, text, date, text);
drop function if exists public.post_journal_entry(uuid, jsonb);
drop function if exists public.seed_default_accounts(uuid);
drop function if exists private.acct_assert_access(uuid);
drop table if exists public.acct_lines;
drop table if exists public.acct_entries;
drop table if exists public.acct_periods;
drop table if exists public.acct_accounts;
drop function if exists private.acct_check_balanced();
drop function if exists private.acct_immutable();
