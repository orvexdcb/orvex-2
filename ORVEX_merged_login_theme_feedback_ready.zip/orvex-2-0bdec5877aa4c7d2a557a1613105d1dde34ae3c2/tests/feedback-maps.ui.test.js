const {JSDOM}=require('jsdom');const fs=require('fs');
const D='/home/claude/p/'+fs.readdirSync('/home/claude/p').find(x=>x.startsWith('orvex-2'))+'/';
let pass=0,fail=0;const ok=(c,n)=>{c?pass++:fail++;console.log((c?'PASS ':'FAIL ')+n)};
async function boot(roleName){
 const dom=new JSDOM('<body><div class="od-h"><button class="od-bell"></button></div></body>',{runScripts:'dangerously',url:'https://x.test/',pretendToBeVisual:true});
 const w=dom.window;w.eval(fs.readFileSync(D+'vendor/leaflet/leaflet.js','utf8'));
 const calls=[];const DB={feedback:[],shops:[{id:'s1',name:'النور',license_active:true,latitude:null,longitude:null},{id:'s2',name:'محل الأمل',license_active:false,latitude:33.3,longitude:44.4,governorate:'بغداد'}],notes:{}};
 w.__orvexSync={SB:{sess:{uid:'u1'},prof:{role:roleName,full_name:'احمد'},shop:roleName==='founder'?null:'s1',me:{id:'u1'}}};
 w.__orvexRequest=async(p,o)=>{o=o||{};calls.push([o.method||'GET',p,o.body]);const b=o.body?JSON.parse(o.body):null;
  if(p.startsWith('/rest/v1/feedback_requests')&&o.method==='POST'){DB.feedback.push(Object.assign({id:'f'+(DB.feedback.length+1),created_at:new Date().toISOString(),founder_read_at:null},b));return null}
  if(p.startsWith('/rest/v1/feedback_requests')&&o.method==='PATCH'){const id=(p.match(/id=eq\.(\w+)/)||[])[1];const rows=DB.feedback.filter(r=>!id||r.id===id);rows.forEach(r=>Object.assign(r,b));return rows}
  if(p.startsWith('/rest/v1/feedback_requests')){let r=DB.feedback.slice();if(p.includes('founder_read_at=is.null'))r=r.filter(x=>!x.founder_read_at);return r}
  if(p.startsWith('/rest/v1/profiles'))return [];
  if(p.startsWith('/rest/v1/rpc/mall_admin_list'))return [{id:'m1',name:'مجمع الرافدين',shop_ids:['s2']}];
  if(p.startsWith('/rest/v1/feedback_internal_notes')){if(o.method==='POST'){DB.notes[b.request_id]=b.note;return null}const id=p.match(/request_id=eq\.(\w+)/)[1];return DB.notes[id]!=null?[{note:DB.notes[id]}]:[]}
  if(p.startsWith('/rest/v1/shops')&&o.method==='PATCH'){const id=p.match(/id=eq\.(\w+)/)[1];const s=DB.shops.find(x=>x.id===id);Object.assign(s,b);return [s]}
  if(p.startsWith('/rest/v1/shops')){const m=p.match(/id=eq\.(\w+)/);return m?DB.shops.filter(s=>s.id===m[1]):DB.shops}
  return []};
 w.eval(`window.esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));window.jsq=s=>String(s).replace(/['\\\\]/g,'\\\\$&');
 window.toasts=[];window.toast=m=>toasts.push(m);window.closeModal=()=>{const m=document.getElementById('modal');if(m)m.remove()};
 window.modal=(t,b)=>{closeModal();const m=document.createElement('div');m.id='modal';m.innerHTML='<h2>'+t+'</h2><div class="sh-body">'+b+'</div>';document.body.appendChild(m)};
 window.IC={};window.svg=n=>'<svg class="ic" data-i="'+n+'"></svg>';window.dashBell=()=>toasts.push('STOCKBELL');window.db={products:[]};
 window.VIEWS={studio:()=>'<div class="card" id="shopList"></div>',settings:()=>'<div>settings</div>'};`);
 // leaflet src is injected via script tag in app; stub loader by preloading L and making script/link append harmless
 w.eval(fs.readFileSync(D+'feedback.js','utf8'));w.eval(fs.readFileSync(D+'maps.js','utf8'));
 await new Promise(r=>setTimeout(r,150));return{w,DB,calls};
}
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
(async()=>{
 // ---- shop (manager)
 let {w,DB,calls}=await boot('manager');
 const feeds=w.document.querySelectorAll('.od-feed');ok(feeds.length===1,'زر الاقتراحات يظهر مرة واحدة بجانب الجرس');
 ok(feeds[0].nextElementSibling.classList.contains('od-bell')&&!feeds[0].nextElementSibling.classList.contains('od-feed'),'الزر مجاور للجرس مباشرة');
 w.__orvexFeedback.mountTop();w.__orvexFeedback.mountTop();ok(w.document.querySelectorAll('.od-feed').length===1,'لا تكرار بعد إعادة التركيب');
 ok(!w.document.getElementById('orvexFeedbackShortcut'),'لا زر عائم');
 feeds[0].click();await sleep(20);ok(!!w.document.getElementById('ofTitle'),'الضغط يفتح شاشة الاقتراحات');
 w.document.getElementById('ofSend').click();ok(w.toasts.some(t=>/عنوانًا/.test(t)),'يرفض عنوانًا فارغًا');
 w.document.getElementById('ofType').value='bug';w.document.getElementById('ofTitle').value='الطباعة لا تعمل';w.document.getElementById('ofMessage').value='لا تطبع الفاتورة بعد البيع';
 w.document.getElementById('ofSend').click();await sleep(50);
 const p=DB.feedback[0];ok(p&&p.shop_id==='s1'&&p.request_type==='bug'&&p.title==='الطباعة لا تعمل'&&p.status==='new','الحفظ بالحقول الصحيحة وshop_id وstatus=new');
 ok(/تم إرسال طلبك بنجاح/.test(w.document.body.innerHTML)&&/جديد/.test(w.document.getElementById('fbBody').innerHTML),'رسالة النجاح وعرض الحالة «جديد»');
 ok(!calls.some(c=>/internal_notes/.test(c[1])),'المحل لا يقرأ الملاحظات الداخلية');
 ok(!w.document.querySelector('.od-cnt'),'لا عدّاد إشعارات للمحل');
 // staff read-only location card
 let vs=w.VIEWS.settings();ok(/id="locCard"/.test(vs),'بطاقة الموقع في إعدادات المحل');
 await sleep(150);ok(/معلومات الموقع الجغرافي/.test(vs),'البطاقة');
 // ---- founder
 let f=await boot('founder');w=f.w;DB=f.DB;
 DB.feedback.push({id:'f1',shop_id:'s1',request_type:'suggestion',title:'ميزة',message:'أضيفوا ميزة جديدة',status:'new',created_at:'2026-11-07T10:00:00Z',founder_read_at:null,contact_name:'علي'},
  {id:'f2',shop_id:'s2',request_type:'support',title:'مساعدة',message:'احتاج مساعدة',status:'new',created_at:'2026-11-08T10:00:00Z',founder_read_at:null});
 await w.__orvexFeedback.refreshUnread();
 ok(w.document.querySelector('.od-bell:not(.od-feed) .od-cnt').textContent==='2','عدّاد غير المقروء =2');
 ok(w.__orvexFeedback.notifText(DB.feedback[0])==='💡 اقتراح جديد من محل النور','نص الإشعار: اقتراح (محل النور)');
 ok(w.__orvexFeedback.notifText(DB.feedback[1])==='🛟 طلب مساعدة جديد من محل الأمل','نص الإشعار: دعم (لا تكرار لكلمة محل)');
 w.dashBell();await sleep(60);ok(/من محل النور/.test(w.document.getElementById('modal').innerHTML),'الجرس يعرض الإشعارات للمؤسس');
 w.orvexFeedbackMarkRead('f1');await sleep(60);ok(w.document.querySelector('.od-cnt').textContent==='1','تعليم كمقروء يحدّث العدّاد');
 w.orvexFeedbackNotifOpen('f2');await sleep(300);
 ok(!!w.document.getElementById('fbc')&&/احتاج مساعدة/.test(w.document.getElementById('modal').innerHTML),'الضغط على الإشعار يفتح تفاصيل الطلب الصحيح');
 ok(!w.document.querySelector('.od-cnt'),'فتح الطلب يعلّمه مقروءًا');
 ok(/إجمالي الطلبات/.test(w.document.getElementById('fbc').innerHTML),'إحصاءات المركز');
 w.orvexFeedbackNoteSave('f2');w.document.getElementById('fbNote').value='ملاحظة';w.orvexFeedbackNoteSave('f2');await sleep(30);ok(DB.notes.f2==='ملاحظة','حفظ ملاحظة داخلية');
 await w.orvexFeedbackStatus('f2','in_progress');ok(DB.feedback[1].status==='in_progress','تغيير الحالة قيد المراجعة');
 await w.orvexFeedbackStatus('f2','resolved');ok(DB.feedback[1].status==='resolved','تغيير الحالة تمت المعالجة');
 w.document.getElementById('fbs').value='s1';w.orvexFeedbackFilter();ok(w.document.querySelectorAll('#fbList .fb-row').length===1,'تصفية حسب المحل');
 w.document.getElementById('fbs').value='';w.document.getElementById('fbq').value='ميزة';w.orvexFeedbackFilter();ok(w.document.querySelectorAll('#fbList .fb-row').length===1,'بحث نصي');
 w.document.getElementById('fbq').value='';w.orvexFeedbackFilter();
 const rows=[...w.document.querySelectorAll('#fbList .fb-row')].map(r=>r.innerHTML);ok(/محل الأمل/.test(rows[0]),'الترتيب من الأحدث للأقدم');
 ok(/id="fbCard"/.test(w.VIEWS.studio())&&/id="mapCard"/.test(w.VIEWS.studio()),'بطاقتا المركز والخريطة في لوحة المؤسس');
 // validate
 const V=w.__orvexMaps.validateLoc;
 ok(V({latitude:'',longitude:''}).ok&&V({latitude:'',longitude:''}).data.latitude===null,'الموقع اختياري');
 ok(!V({latitude:'33',longitude:''}).ok,'إحداثية ناقصة مرفوضة');ok(!V({latitude:'95',longitude:'44'}).ok,'خط عرض خارج النطاق');
 ok(V({latitude:'33.3152789',longitude:'44.3661'}).data.latitude===33.315279,'تقريب 6 خانات');
 // map screen with real Leaflet
 w.document.getElementById('fbc').remove();
 await w.orvexShopsMap();await sleep(1500);
 const fm=w.document.getElementById('fmap');ok(!!fm,'فتح خريطة المحلات');
 ok(/1 من 2/.test(w.document.getElementById('fm_cnt')?.textContent||fm.textContent),'عدد المحلات ذات المواقع');
 ok(/النور/.test(w.document.getElementById('fm_unplaced')?.innerHTML||''),'قائمة المحلات بلا موقع');
 ok(/مجمع الرافدين/.test(fm.innerHTML),'تصفية المجمع متاحة');
 w.document.getElementById('fm_mall').value='m1';w.orvexMapFilter();ok(!/النور/.test(w.document.getElementById('fm_unplaced').innerHTML),'تصفية حسب المجمع');
 w.document.getElementById('fm_mall').value='';w.document.getElementById('fm_st').value='active';w.orvexMapFilter();ok(!/محل الأمل/.test(w.document.getElementById('fm_placed').innerHTML),'تصفية حسب الحالة');
 w.document.getElementById('fm_st').value='';w.orvexMapFilter();
 // editor + save
 await w.orvexShopLocEdit('s1');await sleep(200);
 w.document.getElementById('lc_lat').value='33.31';w.document.getElementById('lc_lng').value='44.36';w.orvexLocInput();
 ok(!!w.document.querySelector('#lc_g')&&/google\.com\/maps/.test(w.document.getElementById('lc_g').href),'رابط Google Maps في المعاينة');
 w.document.getElementById('lc_city').value='الكرادة';await w.orvexShopLocSave('s1');
 ok(DB.shops[0].latitude===33.31&&DB.shops[0].city==='الكرادة','حفظ الموقع');
 // staff cannot edit
 let st=await boot('staff');await st.w.orvexShopLocEdit('s1');ok(st.w.toasts.some(t=>/لمدير المحل/.test(t))&&!st.calls.some(c=>c[0]==='PATCH'),'الموظف لا يعدّل الموقع');
 // mall manager no button
 let mm=await boot('mall_manager');ok(mm.w.document.querySelectorAll('.od-feed').length===0,'لا زر لمدير المجمع');
 console.log(`\n${pass} passed, ${fail} failed`);process.exit(fail?1:0);
})().catch(e=>{console.error(e);process.exit(2)});
