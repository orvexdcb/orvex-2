
do $t$
declare
  fid uuid := '79f2daed-9068-4c82-9d10-037b86cb2740';
  ma  uuid := '910c5073-e322-4e71-93d3-765c7f64a4ea';
  mb  uuid := '8c22ef9f-0e03-4d41-8f73-8caff1d09581';
  sa  uuid := '6071e05d-5a95-440e-aacb-c70bf7aaa235';
  sb_ uuid := gen_random_uuid();
  fb1 uuid; res jsonb := '{}'::jsonb; n int; enforce boolean; sess uuid;
  procedure_dummy int;
begin
  select coalesce((select c.enforce from private.device_binding_cfg c limit 1),false) into enforce;
  res := res || jsonb_build_object('device_binding_enforced', enforce);
  -- متجر ثانٍ مؤقت ومدير ثانٍ منقول إليه (ضمن المعاملة فقط)
  insert into public.shops(id,name) values (sb_,'TEST_B');
  update public.profiles set shop_id=sb_ where id=mb;
  -- جلسات الأجهزة إن كان الربط مفعّلاً
  -- T1: مدير أ يرسل طلباً
  perform set_config('request.jwt.claims', json_build_object('sub',ma,'role','authenticated')::text, true);
  select session_id into sess from public.device_sessions where user_id=ma limit 1;
  perform set_config('request.jwt.claims', json_build_object('sub',ma,'role','authenticated','session_id',sess)::text, true);
  set local role authenticated;
  begin
    insert into public.feedback_requests(shop_id,submitted_by,request_type,area,title,message,status)
      values (sa,ma,'bug','عام','عنوان اختبار','رسالة اختبار للتحقق','new') returning id into fb1;
    res := res || jsonb_build_object('T1_insert_own_shop','ok');
  exception when others then res := res || jsonb_build_object('T1_insert_own_shop','FAIL '||sqlerrm); end;
  -- T1b: إدخال لمحل آخر مرفوض
  begin
    insert into public.feedback_requests(shop_id,submitted_by,request_type,area,message,status)
      values (sb_,ma,'bug','عام','رسالة محل آخر','new');
    res := res || jsonb_build_object('T1b_insert_other_shop','FAIL (allowed)');
  exception when others then res := res || jsonb_build_object('T1b_insert_other_shop','blocked: '||left(sqlerrm,60)); end;
  select count(*) into n from public.feedback_requests;
  res := res || jsonb_build_object('T2_manager_A_sees_rows', n, 'T2_all_belong_to_A', (select bool_and(shop_id=sa) from public.feedback_requests));
  -- T4: المدير لا يغيّر الحالة
  begin
    update public.feedback_requests set status='resolved' where id=fb1; get diagnostics n = row_count;
    res := res || jsonb_build_object('T4_manager_update_status_rows', n);
  exception when others then res := res || jsonb_build_object('T4_manager_update_status','blocked: '||left(sqlerrm,60)); end;
  -- ملاحظات داخلية مخفية عن المدير
  begin select count(*) into n from public.feedback_internal_notes; res := res || jsonb_build_object('T5_manager_sees_notes', n);
  exception when others then res := res || jsonb_build_object('T5_manager_notes','blocked'); end;
  begin insert into public.feedback_internal_notes(request_id,note) values (fb1,'x'); res := res || jsonb_build_object('T5b_manager_insert_note','FAIL (allowed)');
  exception when others then res := res || jsonb_build_object('T5b_manager_insert_note','blocked'); end;
  -- T6: موقع محل المدير
  begin update public.shops set latitude=33.3152,longitude=44.3661,governorate='بغداد',city='الكرادة' where id=sa; get diagnostics n=row_count;
    res := res || jsonb_build_object('T6_manager_update_own_shop_location_rows', n);
  exception when others then res := res || jsonb_build_object('T6_own_loc','FAIL '||left(sqlerrm,80)); end;
  begin update public.shops set latitude=200,longitude=44 where id=sa; res := res || jsonb_build_object('T6b_invalid_lat','FAIL (allowed)');
  exception when others then res := res || jsonb_build_object('T6b_invalid_lat','blocked'); end;
  begin update public.shops set latitude=10,longitude=10 where id=sb_; get diagnostics n=row_count; res := res || jsonb_build_object('T6c_manager_update_other_shop_rows', n);
  exception when others then res := res || jsonb_build_object('T6c','blocked'); end;
  select count(*) into n from public.shops where id=sb_; res := res || jsonb_build_object('T6d_manager_sees_other_shop_rows', n);
  reset role;
  -- مدير ب لا يرى طلبات أ
  perform set_config('request.jwt.claims', json_build_object('sub',mb,'role','authenticated','session_id',(select session_id from public.device_sessions where user_id=mb limit 1))::text, true);
  set local role authenticated;
  select count(*) into n from public.feedback_requests; res := res || jsonb_build_object('T3_manager_B_sees_rows', n);
  select count(*) into n from public.feedback_requests where shop_id=sa; res := res || jsonb_build_object('T3_manager_B_sees_A_rows', n);
  reset role;
  -- المؤسس
  perform set_config('request.jwt.claims', json_build_object('sub',fid,'role','authenticated','session_id',(select session_id from public.device_sessions where user_id=fid limit 1))::text, true);
  set local role authenticated;
  select count(*) into n from public.feedback_requests; res := res || jsonb_build_object('T7_founder_sees_rows', n);
  update public.feedback_requests set status='in_progress', founder_read_at=now() where id=fb1; get diagnostics n=row_count; res := res || jsonb_build_object('T7_founder_status_rows', n);
  insert into public.feedback_internal_notes(request_id,note,updated_by) values (fb1,'ملاحظة داخلية',fid); 
  select count(*) into n from public.feedback_internal_notes; res := res || jsonb_build_object('T7_founder_notes', n);
  update public.shops set latitude=30.5,longitude=47.78 where id=sb_; get diagnostics n=row_count; res := res || jsonb_build_object('T8_founder_update_other_shop_rows', n);
  res := res || jsonb_build_object('T8_stamp_set', (select location_updated_at is not null and location_updated_by=fid from public.shops where id=sb_));
  reset role;
  -- المحل لا يرى الملاحظة بعد الآن / الحالة المحدّثة ظاهرة للمدير أ
  perform set_config('request.jwt.claims', json_build_object('sub',ma,'role','authenticated','session_id',sess)::text, true);
  set local role authenticated;
  res := res || jsonb_build_object('T9_manager_A_sees_status',(select status from public.feedback_requests where id=fb1));
  reset role;
  -- anon
  set local role anon;
  begin perform 1 from public.feedback_requests limit 1; res := res || jsonb_build_object('T10_anon_select','FAIL (allowed)');
  exception when others then res := res || jsonb_build_object('T10_anon_select','blocked'); end;
  reset role;
  raise exception 'DRYRUN_RESULT %', res::text;
end $t$;
