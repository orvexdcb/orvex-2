-- ORVEX: مركز الاقتراحات + الإشعارات + موقع المحل. تعديلات إضافية فقط (لا حذف ولا تغيير لمعرفات أو بيانات موجودة).
-- التراجع: supabase/rollback/20261107210000_feedback_center_and_shop_location_down.sql

-- 1) feedback_requests: عنوان + قراءة المؤسس + تاريخ آخر تحديث (الجدول نفسه، دون جدول بديل)
alter table public.feedback_requests add column if not exists title text null;
alter table public.feedback_requests add column if not exists founder_read_at timestamptz null;
alter table public.feedback_requests add column if not exists updated_at timestamptz not null default now();
do $$ begin
  if not exists (select 1 from pg_constraint where conname='feedback_requests_title_len') then
    alter table public.feedback_requests add constraint feedback_requests_title_len
      check (title is null or char_length(title) between 1 and 150);
  end if;
end $$;

-- 2) الملاحظات الداخلية في جدول منفصل للمؤسس فقط (الصلاحيات على مستوى الأعمدة لا تفرّق بين مؤسس ومحل)
create table if not exists public.feedback_internal_notes (
  request_id uuid primary key references public.feedback_requests(id) on delete cascade,
  note text not null default '' check (char_length(note) <= 5000),
  updated_by uuid null references auth.users(id) on delete set null,
  updated_at timestamptz not null default now()
);
alter table public.feedback_internal_notes enable row level security;
revoke all on table public.feedback_internal_notes from anon, authenticated;
grant select, insert, update on table public.feedback_internal_notes to authenticated;
drop policy if exists feedback_notes_founder_all on public.feedback_internal_notes;
create policy feedback_notes_founder_all on public.feedback_internal_notes
  for all to authenticated
  using ((select private.my_role()) = 'founder')
  with check ((select private.my_role()) = 'founder');

-- 3) صلاحيات الأعمدة: المحل يرى طلباته فقط (دون الملاحظات الداخلية)، والمؤسس وحده يغيّر الحالة
grant select (title, founder_read_at, updated_at) on public.feedback_requests to authenticated;
grant insert (title) on public.feedback_requests to authenticated;
grant update (status, founder_read_at, updated_at) on public.feedback_requests to authenticated;

drop policy if exists feedback_requests_shop_read on public.feedback_requests;
create policy feedback_requests_shop_read on public.feedback_requests
  for select to authenticated
  using (
    (select private.my_role()) = 'manager' and shop_id = (select private.my_shop())
    or (select private.my_role()) = 'staff' and shop_id = (select private.my_shop()) and submitted_by = (select auth.uid())
  );

-- منع غير المؤسس من تغيير الحالة أو علامة القراءة حتى لو توفرت له صلاحية عمود (الأمان على مستوى السياسة)
-- سياسة التحديث الحالية feedback_requests_founder_status_update تقصر UPDATE على المؤسس، وهي لم تتغير.
create or replace function private.feedback_touch() returns trigger
language plpgsql security definer set search_path = '' as $$
begin new.updated_at := now(); return new; end $$;
drop trigger if exists trg_feedback_touch on public.feedback_requests;
create trigger trg_feedback_touch before update on public.feedback_requests
  for each row execute function private.feedback_touch();

create index if not exists feedback_requests_unread_idx
  on public.feedback_requests (created_at desc) where founder_read_at is null;

-- 4) موقع المحل: أعمدة اختيارية (null) على جدول shops الحالي، دون تغيير المعرفات
alter table public.shops
  add column if not exists governorate text null,
  add column if not exists city text null,
  add column if not exists address text null,
  add column if not exists street text null,
  add column if not exists landmark text null,
  add column if not exists latitude double precision null,
  add column if not exists longitude double precision null,
  add column if not exists location_updated_at timestamptz null,
  add column if not exists location_updated_by uuid null references auth.users(id) on delete set null;
do $$ begin
  if not exists (select 1 from pg_constraint where conname='shops_location_valid') then
    alter table public.shops add constraint shops_location_valid check (
      (latitude is null and longitude is null)
      or (latitude between -90 and 90 and longitude between -180 and 180 and latitude is not null and longitude is not null))
      not valid;
    alter table public.shops validate constraint shops_location_valid;
  end if;
  if not exists (select 1 from pg_constraint where conname='shops_location_text_len') then
    alter table public.shops add constraint shops_location_text_len check (
      coalesce(char_length(governorate),0)<=80 and coalesce(char_length(city),0)<=120
      and coalesce(char_length(address),0)<=300 and coalesce(char_length(street),0)<=150
      and coalesce(char_length(landmark),0)<=200);
  end if;
end $$;

-- الأعمدة الجديدة تتبع سياسات RLS الحالية على shops (المؤسس: الكل، المدير: محله فقط، الموظف: لا تعديل)
grant select (governorate,city,address,street,landmark,latitude,longitude,location_updated_at,location_updated_by) on public.shops to authenticated;
grant update (governorate,city,address,street,landmark,latitude,longitude) on public.shops to authenticated;

-- ختم تاريخ/مستخدم تعديل الموقع من الخادم (لا يثق بقيم العميل)
create or replace function private.shop_location_stamp() returns trigger
language plpgsql security definer set search_path = '' as $$
begin
  if (new.latitude, new.longitude, new.governorate, new.city, new.address, new.street, new.landmark)
     is distinct from (old.latitude, old.longitude, old.governorate, old.city, old.address, old.street, old.landmark) then
    new.location_updated_at := now(); new.location_updated_by := auth.uid();
  else
    new.location_updated_at := old.location_updated_at; new.location_updated_by := old.location_updated_by;
  end if;
  return new;
end $$;
drop trigger if exists trg_shop_location_stamp on public.shops;
create trigger trg_shop_location_stamp before update on public.shops
  for each row execute function private.shop_location_stamp();

notify pgrst, 'reload schema';
