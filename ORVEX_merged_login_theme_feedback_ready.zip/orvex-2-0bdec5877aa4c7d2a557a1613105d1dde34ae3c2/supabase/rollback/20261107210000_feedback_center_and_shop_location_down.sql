-- تراجع عن 20261107210000 (يحذف الأعمدة والجدول الجديدة فقط؛ لا يمس أي بيانات أخرى)
drop trigger if exists trg_shop_location_stamp on public.shops;
drop function if exists private.shop_location_stamp();
alter table public.shops drop constraint if exists shops_location_valid, drop constraint if exists shops_location_text_len;
alter table public.shops drop column if exists governorate, drop column if exists city, drop column if exists address,
  drop column if exists street, drop column if exists landmark, drop column if exists latitude, drop column if exists longitude,
  drop column if exists location_updated_at, drop column if exists location_updated_by;
drop trigger if exists trg_feedback_touch on public.feedback_requests;
drop function if exists private.feedback_touch();
drop policy if exists feedback_requests_shop_read on public.feedback_requests;
drop index if exists public.feedback_requests_unread_idx;
drop table if exists public.feedback_internal_notes;
alter table public.feedback_requests drop constraint if exists feedback_requests_title_len;
alter table public.feedback_requests drop column if exists title, drop column if exists founder_read_at, drop column if exists updated_at;
notify pgrst, 'reload schema';
